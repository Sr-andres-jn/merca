import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MarketsList } from './components/MarketsList';
import { ProductCatalog } from './components/ProductCatalog';
import { AiAssistantModal } from './components/AiAssistantModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { SideMenu } from './components/SideMenu';
import { AiFloatingButton } from './components/AiFloatingButton';
import { MobileStatusBar } from './components/MobileStatusBar';
import { MobileBottomNav, MobileTab } from './components/MobileBottomNav';
import { OrdersView } from './components/OrdersView';
import { QuickListModal } from './components/QuickListModal';
import { AuthModal, AuthMode } from './components/AuthModal';
import { AuthScreen } from './components/AuthScreen';
import { DatabaseModal } from './components/DatabaseModal';
import { Smartphone, Monitor, Database } from 'lucide-react';
import { Market, Product, CartItem, Order, QuickListItem, AuthUser } from './types';
import { INITIAL_MARKETS, INITIAL_PRODUCTS, QUICK_LISTS } from './data/mockData';

export type PhoneInchSize = '6.0' | '6.4' | '6.8';

export default function App() {
  const [markets, setMarkets] = useState<Market[]>(INITIAL_MARKETS);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [quickLists, setQuickLists] = useState<QuickListItem[]>(QUICK_LISTS);
  const [selectedMarketId, setSelectedMarketId] = useState<string>('mercado-central');
  const [selectedCity, setSelectedCity] = useState<string>('Madrid, Cundinamarca (Centro / La Prosperidad)');

  // User Authentication State
  const [user, setUser] = useState<AuthUser | null>(() => {
    try {
      const saved = localStorage.getItem('merca_easy_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [isGuest, setIsGuest] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<AuthMode>('login');

  // Database Modal State
  const [isDatabaseOpen, setIsDatabaseOpen] = useState(false);

  // Mobile App Navigation Tab
  const [activeTab, setActiveTab] = useState<MobileTab>('inicio');

  // Screen size between 6.0 and 6.8 inches
  const [phoneSize, setPhoneSize] = useState<PhoneInchSize>('6.4');

  // Device frame simulation toggle on desktop
  const [isPhoneFrame, setIsPhoneFrame] = useState<boolean>(true);

  // Cart state
  const [cart, setCart] = useState<CartItem[]>(() => {
    const sampleProduct = INITIAL_PRODUCTS[0];
    return sampleProduct ? [{ product: sampleProduct, quantity: 1 }] : [];
  });

  // Modals state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [aiPrompt, setAiPrompt] = useState<string | undefined>(undefined);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [previewList, setPreviewList] = useState<QuickListItem | null>(null);
  const [userOrders, setUserOrders] = useState<Order[]>([]);

  // Fetch backend data if available
  useEffect(() => {
    fetch('/api/markets')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.markets) setMarkets(data.markets);
      })
      .catch(() => {});

    fetch('/api/products')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.products) setProducts(data.products);
      })
      .catch(() => {});

    fetch('/api/orders')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.orders) setUserOrders(data.orders);
      })
      .catch(() => {});
  }, []);

  // Cart management
  const handleAddToCart = (product: Product, delta: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        const newQty = existing.quantity + delta;
        if (newQty <= 0) {
          return prev.filter((item) => item.product.id !== product.id);
        }
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: newQty } : item
        );
      } else {
        if (delta > 0) {
          return [...prev, { product, quantity: delta }];
        }
        return prev;
      }
    });
  };

  const handleUpdateQuantity = (product: Product, delta: number) => {
    handleAddToCart(product, delta);
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleAddPresetToCart = (items: { product: Product; quantity: number }[]) => {
    setCart((prev) => {
      let updated = [...prev];
      for (const item of items) {
        const idx = updated.findIndex((i) => i.product.id === item.product.id);
        if (idx >= 0) {
          updated[idx] = {
            ...updated[idx],
            quantity: updated[idx].quantity + item.quantity,
          };
        } else {
          updated.push({ product: item.product, quantity: item.quantity });
        }
      }
      return updated;
    });
  };

  const handleOpenAiWithPrompt = (prompt: string) => {
    setAiPrompt(prompt);
    setIsAiOpen(true);
  };

  const handleOpenAuth = (mode: AuthMode = 'login') => {
    setAuthMode(mode);
    setIsAuthOpen(true);
  };

  const handleLoginSuccess = (newUser: AuthUser) => {
    setUser(newUser);
    try {
      localStorage.setItem('merca_easy_user', JSON.stringify(newUser));
    } catch {}
  };

  const handleLogout = () => {
    setUser(null);
    setIsGuest(false);
    try {
      localStorage.removeItem('merca_easy_user');
    } catch {}
  };

  const handleOrderCompleted = (order: Order) => {
    setCurrentOrder(order);
    setUserOrders((prev) => [order, ...prev]);
    setIsCheckoutOpen(false);
    setIsCartOpen(false);
    setCart([]);
    setActiveTab('pedidos');
  };

  const currentMarket =
    selectedMarketId === 'todos'
      ? undefined
      : markets.find((m) => m.id === selectedMarketId);

  const displayedProducts =
    selectedMarketId === 'todos'
      ? products
      : products.filter((p) => p.marketId === selectedMarketId);

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // App Content based on active tab
  const renderTabContent = () => {
    switch (activeTab) {
      case 'inicio':
        return (
          <div className="space-y-4 p-3.5 sm:p-4">
            {/* 1. Mercados Disponibles en Madrid, Cundinamarca */}
            <div className="bg-white rounded-2xl border border-orange-100 p-4 shadow-2xs">
              <MarketsList
                markets={markets}
                selectedMarketId={selectedMarketId}
                onSelectMarket={(id) => {
                  setSelectedMarketId(id);
                }}
                onExploreProducts={() => setActiveTab('productos')}
              />
            </div>

            {/* 2. Catálogo Directo de Productos Frescos del Mercado Seleccionado */}
            <ProductCatalog
              products={displayedProducts}
              currentMarket={currentMarket}
              cart={cart}
              onAddToCart={handleAddToCart}
              onOpenAiRecipe={() => {
                setAiPrompt('Recomiéndame una receta típica con productos de este mercado');
                setIsAiOpen(true);
              }}
            />
          </div>
        );

      case 'productos':
        return (
          <div className="p-3.5 sm:p-4">
            <ProductCatalog
              products={displayedProducts}
              currentMarket={currentMarket}
              cart={cart}
              onAddToCart={handleAddToCart}
              onOpenAiRecipe={() => {
                setAiPrompt('Recomiéndame una receta típica con productos de este mercado');
                setIsAiOpen(true);
              }}
            />
          </div>
        );

      case 'ia':
        return (
          <div className="p-3.5 sm:p-4">
            <div className="bg-white rounded-2xl border border-orange-200 p-4 text-center shadow-xs">
              <div className="w-14 h-14 bg-amber-100 text-[#ea580c] rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">✨</span>
              </div>
              <h2 className="font-black text-gray-900 text-lg">Asistente Merca AI</h2>
              <p className="text-xs text-gray-600 mt-1 max-w-sm mx-auto">
                Tu asesor de compras en plazas de mercado potenciado por Gemini 3.8.
              </p>
              <button
                onClick={() => {
                  setAiPrompt(undefined);
                  setIsAiOpen(true);
                }}
                className="mt-4 w-full bg-[#f97316] hover:bg-[#ea580c] text-white font-extrabold py-3 px-4 rounded-xl shadow-md text-sm transition-all flex items-center justify-center gap-2"
              >
                <span>Abrir Chat Inteligente</span>
              </button>
            </div>
          </div>
        );

      case 'canasta':
        return (
          <div className="p-3.5 sm:p-4">
            <div className="bg-white rounded-2xl border border-orange-200 p-4 shadow-xs">
              <h2 className="text-lg font-black text-gray-900 mb-2">Canasta de Compras</h2>
              {cart.length === 0 ? (
                <div className="text-center py-10">
                  <p className="text-xs text-gray-500">Tu canasta está vacía</p>
                  <button
                    onClick={() => setActiveTab('inicio')}
                    className="mt-3 text-xs font-bold text-orange-600 underline"
                  >
                    Ver mercados disponibles
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {cart.map((item) => (
                    <div
                      key={item.product.id}
                      className="flex items-center justify-between gap-2 p-2.5 rounded-xl border border-gray-100 bg-[#fffaf5]"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-xs truncate">{item.product.name}</p>
                        <p className="text-[10px] text-gray-500">{item.product.stallName}</p>
                        <p className="text-xs font-black text-orange-600">
                          ${(item.product.price * item.quantity).toLocaleString('es-CO')}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleAddToCart(item.product, -1)}
                          className="w-6 h-6 rounded bg-gray-200 flex items-center justify-center text-xs font-bold"
                        >
                          -
                        </button>
                        <span className="text-xs font-bold w-4 text-center">{item.quantity}</span>
                        <button
                          onClick={() => handleAddToCart(item.product, 1)}
                          className="w-6 h-6 rounded bg-orange-500 text-white flex items-center justify-center text-xs font-bold"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  ))}

                  <button
                    onClick={() => setIsCheckoutOpen(true)}
                    className="w-full mt-4 bg-[#f97316] hover:bg-[#ea580c] text-white font-black py-3 rounded-xl shadow-md text-sm"
                  >
                    Confirmar Pedido
                  </button>
                </div>
              )}
            </div>
          </div>
        );

      case 'pedidos':
        return (
          <OrdersView
            orders={userOrders}
            user={user}
            onOpenAuth={handleOpenAuth}
            onSelectOrder={(order) => setCurrentOrder(order)}
            onExploreMarkets={() => setActiveTab('inicio')}
          />
        );

      default:
        return null;
    }
  };

  // Sizing definitions for 6.0" (min) to 6.8" (max) smartphone viewports
  const phoneSpecs = {
    '6.0': { widthClass: 'sm:w-[380px]', heightClass: 'sm:h-[820px]', diagonal: '6.0 pulgadas (Mínimo)' },
    '6.4': { widthClass: 'sm:w-[408px]', heightClass: 'sm:h-[875px]', diagonal: '6.4 pulgadas (Estándar)' },
    '6.8': { widthClass: 'sm:w-[438px]', heightClass: 'sm:h-[935px]', diagonal: '6.8 pulgadas (Máximo)' },
  }[phoneSize];

  return (
    <div className="min-h-screen bg-[#22130c] sm:bg-[#e8dfd5] flex flex-col items-center justify-start font-sans py-0 sm:py-3 select-none">
      {/* Top Device Simulator Bar for Desktop: 6.0" to 6.8" Sizing Controls */}
      <div className="hidden sm:flex items-center justify-between w-full max-w-2xl px-4 py-2 text-xs text-gray-700 font-medium bg-white/90 backdrop-blur-md rounded-2xl shadow-xs border border-orange-200/80 mb-2">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-orange-600" />
          <span className="font-extrabold text-gray-900">Dimensiones de Pantalla:</span>
          <span className="bg-orange-100 text-orange-800 text-[11px] font-black px-2.5 py-0.5 rounded-full">
            {phoneSpecs.diagonal}
          </span>
        </div>

        {/* 6.0" to 6.8" Inch Toggles & Database Trigger */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsDatabaseOpen(true)}
            className="flex items-center gap-1.5 bg-orange-100 hover:bg-orange-200 text-orange-950 font-bold px-2.5 py-1 rounded-xl text-xs transition-colors border border-orange-300/60 shadow-2xs"
            title="Abrir inspector de la base de datos persistente"
          >
            <Database className="w-3.5 h-3.5 text-orange-600" />
            <span>Base de Datos</span>
          </button>

          <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl">
            <button
              onClick={() => setPhoneSize('6.0')}
              className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                phoneSize === '6.0'
                  ? 'bg-[#f97316] text-white shadow-2xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Pantalla de 6.0 pulgadas (Mínimo)"
            >
              6.0" Mín
            </button>

            <button
              onClick={() => setPhoneSize('6.4')}
              className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                phoneSize === '6.4'
                  ? 'bg-[#f97316] text-white shadow-2xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Pantalla de 6.4 pulgadas (Estándar)"
            >
              6.4"
            </button>

            <button
              onClick={() => setPhoneSize('6.8')}
              className={`px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                phoneSize === '6.8'
                  ? 'bg-[#f97316] text-white shadow-2xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Pantalla de 6.8 pulgadas (Máximo)"
            >
              6.8" Máx
            </button>
          </div>
        </div>
      </div>

      {/* Main Smartphone Shell (Strictly between 6.0" and 6.8" dimensions: 380px - 438px) */}
      <div
        className={`w-full transition-all duration-300 min-w-[360px] max-w-[438px] ${phoneSpecs.widthClass} ${phoneSpecs.heightClass} sm:my-1 sm:shadow-2xl sm:rounded-[44px] sm:border-[9px] sm:border-[#141414] overflow-hidden relative bg-[#faf6f0] flex flex-col`}
      >
        {/* Dynamic Island / Punch Hole cutout */}
        <div className="hidden sm:flex items-center justify-center pt-2 pb-1 bg-[#f97316]">
          <div className="w-24 h-4 bg-black/40 rounded-full" />
        </div>

        {/* Mobile Status Bar (9:41, 5G, Batería) */}
        <MobileStatusBar />

        {/* ============================================================== */}
        {/* CONDITIONAL FIRST SCREEN: REGISTRO / AUTENTICACIÓN OBLIGATORIA */}
        {/* La interfaz de registro de usuario es lo primero que aparece     */}
        {/* antes de abrir la aplicación principal.                        */}
        {/* ============================================================== */}
        {!user && !isGuest ? (
          <div className="flex-1 overflow-y-auto flex flex-col bg-white">
            <AuthScreen
              onAuthSuccess={handleLoginSuccess}
              onExploreAsGuest={() => setIsGuest(true)}
              initialMode="register"
            />
          </div>
        ) : (
          /* ============================================================== */
          /* APLICACIÓN PRINCIPAL (DESPUÉS DEL REGISTRO O INICIO DE SESIÓN) */
          /* ============================================================== */
          <div className="flex-1 flex flex-col justify-between overflow-hidden">
            {/* Top Header matching Figma navigation */}
            <Header
              cart={cart}
              user={user}
              onOpenCart={() => setIsCartOpen(true)}
              onOpenAi={() => {
                setAiPrompt(undefined);
                setIsAiOpen(true);
              }}
              onOpenMenu={() => setIsMenuOpen(true)}
              onOpenAuth={handleOpenAuth}
              selectedCity={selectedCity}
              onSelectCity={setSelectedCity}
            />

            {/* Tab Content Area with Smooth Scrolling */}
            <div className="flex-1 overflow-y-auto pb-4">{renderTabContent()}</div>

            {/* Floating Action Button "PEDIR YA" on home */}
            {activeTab === 'inicio' && (
              <AiFloatingButton
                onClick={() => {
                  setAiPrompt(undefined);
                  setIsAiOpen(true);
                }}
              />
            )}

            {/* Native Mobile Bottom Navigation Bar */}
            <MobileBottomNav
              activeTab={activeTab}
              onSelectTab={(tab) => setActiveTab(tab)}
              cartCount={totalCartCount}
            />
          </div>
        )}
      </div>

      {/* Slide-out Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        onOpenAi={() => setIsAiOpen(true)}
      />

      {/* AI Assistant Modal (Interfaz con IA) */}
      <AiAssistantModal
        isOpen={isAiOpen}
        onClose={() => {
          setIsAiOpen(false);
          setAiPrompt(undefined);
        }}
        cart={cart}
        currentMarketId={selectedMarketId}
        onAddToCart={handleAddToCart}
        initialPrompt={aiPrompt}
      />

      {/* Quick List Preview Modal */}
      <QuickListModal
        list={previewList}
        allProducts={products}
        onClose={() => setPreviewList(null)}
        onAddListToCart={(items) => {
          handleAddPresetToCart(items);
          setIsCartOpen(true);
        }}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        user={user}
        onOrderCompleted={handleOrderCompleted}
      />

      {/* Order Success Tracker */}
      <OrderSuccessModal
        order={currentOrder}
        onClose={() => setCurrentOrder(null)}
      />

      {/* Side Menu Drawer */}
      <SideMenu
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        onOpenAi={() => {
          setIsMenuOpen(false);
          setIsAiOpen(true);
        }}
        onSelectMarket={(id) => {
          setSelectedMarketId(id);
          setIsMenuOpen(false);
          setActiveTab('productos');
        }}
        selectedCity={selectedCity}
        onSelectCity={setSelectedCity}
        user={user}
        onOpenAuth={handleOpenAuth}
        onLogout={handleLogout}
        onOpenDatabase={() => setIsDatabaseOpen(true)}
      />

      {/* Authentication Modal (Login, Registro, Recuperación de Contraseña, Google y Apple) */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        initialMode={authMode}
      />

      {/* Database Inspector & Persistence Manager Modal */}
      <DatabaseModal
        isOpen={isDatabaseOpen}
        onClose={() => setIsDatabaseOpen(false)}
      />
    </div>
  );
}
