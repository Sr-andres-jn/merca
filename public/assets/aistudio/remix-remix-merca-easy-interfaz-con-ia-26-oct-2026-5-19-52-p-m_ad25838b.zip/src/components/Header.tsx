import React from 'react';
import { ShoppingCart, Menu, Sparkles, MapPin, User, LogIn } from 'lucide-react';
import { CartItem, AuthUser } from '../types';

interface HeaderProps {
  cart: CartItem[];
  user: AuthUser | null;
  onOpenCart: () => void;
  onOpenAi: () => void;
  onOpenMenu: () => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
  selectedCity: string;
  onSelectCity: (city: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cart,
  user,
  onOpenCart,
  onOpenAi,
  onOpenMenu,
  onOpenAuth,
  selectedCity,
}) => {
  const totalItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  return (
    <header className="sticky top-0 z-40 bg-[#f97316] text-white shadow-md">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-2">
        {/* Left: Menu & Brand */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onOpenMenu}
            className="p-1.5 sm:p-2 rounded-lg hover:bg-orange-600 active:bg-orange-700 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            aria-label="Abrir menú"
          >
            <Menu className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          <div className="flex items-center gap-1.5 sm:gap-2 select-none cursor-pointer">
            <div className="bg-white text-[#f97316] p-1 sm:p-1.5 rounded-lg shadow-sm">
              <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5 fill-current" />
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold tracking-wider text-base sm:text-xl leading-none">
                MERCA EASY!
              </span>
              <span className="text-[9px] sm:text-[10px] font-medium text-orange-100 tracking-wide">
                Plaza & Campo con IA
              </span>
            </div>
          </div>
        </div>

        {/* Center: Delivery Location (hidden on very small screens) */}
        <div className="hidden md:flex items-center gap-1.5 bg-orange-600/80 hover:bg-orange-600 px-3 py-1.5 rounded-full text-xs transition-colors cursor-pointer border border-orange-400/30">
          <MapPin className="w-3.5 h-3.5 text-orange-200" />
          <span className="text-orange-100">Entrega en:</span>
          <span className="font-semibold text-white truncate max-w-[150px]">{selectedCity}</span>
        </div>

        {/* Right Actions: User Auth, AI Assistant & Cart */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* User Auth Profile Button */}
          {user ? (
            <button
              onClick={() => onOpenMenu()}
              className="flex items-center gap-1.5 bg-orange-600/90 hover:bg-orange-700 py-1 px-2 sm:px-2.5 rounded-full text-xs font-bold border border-orange-400/40 transition-colors"
              title={`Conectado como ${user.name}`}
            >
              <img
                src={user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120'}
                alt={user.name}
                className="w-5 h-5 rounded-full object-cover border border-white shrink-0"
              />
              <span className="max-w-[75px] sm:max-w-[100px] truncate text-[11px] sm:text-xs">
                {user.name.split(' ')[0]}
              </span>
            </button>
          ) : (
            <button
              onClick={() => onOpenAuth('login')}
              className="flex items-center gap-1 bg-white text-orange-700 hover:bg-orange-50 font-extrabold py-1 px-2.5 rounded-full text-xs shadow-xs transition-transform active:scale-95"
              title="Iniciar sesión o registrarse"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span className="hidden xs:inline text-[11px] sm:text-xs">Ingresar</span>
            </button>
          )}

          {/* AI Helper Trigger */}
          <button
            onClick={onOpenAi}
            className="flex items-center gap-1 bg-amber-400 hover:bg-amber-300 text-orange-950 font-bold px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-xs shadow-sm transition-transform active:scale-95"
            title="Abrir Asistente con Inteligencia Artificial"
          >
            <Sparkles className="w-3.5 h-3.5 fill-amber-500 text-orange-950" />
            <span className="hidden sm:inline">Asistente IA</span>
            <span className="sm:hidden text-[11px]">IA</span>
          </button>

          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center gap-1.5 sm:gap-2 bg-orange-700/80 hover:bg-orange-800 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            aria-label={`Ver carrito con ${totalItemCount} productos`}
          >
            <ShoppingCart className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            {totalItemCount > 0 ? (
              <>
                <span className="bg-white text-orange-600 font-extrabold px-1.5 py-0.2 text-[10px] sm:text-[11px] rounded-full min-w-4 text-center">
                  {totalItemCount}
                </span>
                <span className="hidden lg:inline font-bold">
                  ${cartSubtotal.toLocaleString('es-CO')}
                </span>
              </>
            ) : (
              <span className="hidden sm:inline text-xs">Carrito</span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
