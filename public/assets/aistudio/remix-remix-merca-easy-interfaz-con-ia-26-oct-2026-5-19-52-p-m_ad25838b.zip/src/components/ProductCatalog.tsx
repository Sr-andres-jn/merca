import React, { useState } from 'react';
import { Search, Plus, Minus, Check, Sparkles, Filter, Store } from 'lucide-react';
import { Product, CartItem, Market } from '../types';

interface ProductCatalogProps {
  products: Product[];
  currentMarket?: Market;
  cart: CartItem[];
  onAddToCart: (product: Product, delta?: number) => void;
  onOpenAiRecipe: () => void;
}

type CategoryFilter = 'todos' | 'frutas' | 'verduras' | 'carnes' | 'pescados' | 'campesino' | 'lacteos' | 'granos';

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  products,
  currentMarket,
  cart,
  onAddToCart,
  onOpenAiRecipe,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<CategoryFilter>('todos');

  const categories: { id: CategoryFilter; label: string }[] = [
    { id: 'todos', label: 'Todos' },
    { id: 'frutas', label: 'Frutas' },
    { id: 'verduras', label: 'Verduras' },
    { id: 'carnes', label: 'Carnes' },
    { id: 'pescados', label: 'Pescados' },
    { id: 'campesino', label: 'Campesino' },
    { id: 'lacteos', label: 'Lácteos' },
    { id: 'granos', label: 'Granos' },
  ];

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.stallName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      activeCategory === 'todos' || product.category === activeCategory;

    return matchesSearch && matchesCategory;
  });

  const getCartQuantity = (productId: string) => {
    const item = cart.find((i) => i.product.id === productId);
    return item ? item.quantity : 0;
  };

  return (
    <section className="bg-white rounded-2xl border border-orange-100 p-4 sm:p-5 shadow-xs">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-gray-900">
              {currentMarket ? currentMarket.name : 'Productos de la Plaza'}
            </h2>
            {currentMarket && (
              <span className="text-xs bg-orange-100 text-orange-800 font-semibold px-2 py-0.5 rounded-full">
                {currentMarket.status}
              </span>
            )}
          </div>
          <p className="text-xs text-gray-500 mt-0.5">
            {currentMarket
              ? `${currentMarket.vendorsCount} puestos activos · ${filteredProducts.length} productos listados`
              : 'Directo de productores campesinos y puesteros'}
          </p>
        </div>

        {/* Search input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar aguacate, papa, carne, puesto..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all placeholder:text-gray-400"
          />
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-4 scrollbar-none">
        {categories.map((cat) => {
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-orange-500 text-white shadow-xs'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Product Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-12 px-4 border-2 border-dashed border-gray-200 rounded-xl">
          <Store className="w-10 h-10 text-gray-300 mx-auto mb-2" />
          <p className="text-sm font-semibold text-gray-700">No encontramos productos</p>
          <p className="text-xs text-gray-500 mt-1">Prueba con otra palabra o selecciona otro mercado.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setActiveCategory('todos');
            }}
            className="mt-3 text-xs font-bold text-orange-600 hover:underline"
          >
            Restablecer filtros
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
          {filteredProducts.map((product) => {
            const qty = getCartQuantity(product.id);

            return (
              <div
                key={product.id}
                className="group bg-white rounded-xl border border-gray-200/80 hover:border-orange-300 hover:shadow-md transition-all flex flex-col overflow-hidden"
              >
                {/* Image Container */}
                <div className="relative h-36 w-full bg-gray-100 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {product.freshBadge && (
                    <span className="absolute top-2 left-2 bg-emerald-700/90 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-xs">
                      {product.freshBadge}
                    </span>
                  )}
                  {product.organic && (
                    <span className="absolute top-2 right-2 bg-amber-500/95 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-xs">
                      Orgánico
                    </span>
                  )}
                </div>

                {/* Details */}
                <div className="p-3 sm:p-3.5 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Stall Info */}
                    <div className="flex items-center justify-between text-[11px] text-gray-500 mb-1">
                      <span className="font-medium text-orange-700 truncate">
                        {product.stallName}
                      </span>
                      <span className="text-gray-400 text-[10px] shrink-0">
                        {product.stallNumber}
                      </span>
                    </div>

                    {/* Product Name */}
                    <h3 className="font-bold text-gray-900 text-sm leading-snug group-hover:text-orange-600 transition-colors">
                      {product.name}
                    </h3>

                    {/* Short Description */}
                    <p className="text-xs text-gray-500 line-clamp-2 mt-1">
                      {product.description}
                    </p>
                  </div>

                  {/* Price & Action */}
                  <div className="mt-3 pt-2.5 border-t border-gray-100 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-gray-400 block -mb-0.5">Precio</span>
                      <div className="flex items-baseline gap-1">
                        <span className="font-black text-gray-900 text-base">
                          ${product.price.toLocaleString('es-CO')}
                        </span>
                        <span className="text-[11px] text-gray-500">/{product.unit}</span>
                      </div>
                    </div>

                    {/* Cart Controller */}
                    {qty > 0 ? (
                      <div className="flex items-center gap-1.5 bg-orange-50 border border-orange-200 rounded-lg p-1">
                        <button
                          onClick={() => onAddToCart(product, -1)}
                          className="w-6 h-6 rounded-md bg-white text-orange-700 font-bold flex items-center justify-center hover:bg-orange-100 active:scale-95 transition-all"
                          aria-label="Restar uno"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-extrabold text-orange-950 text-xs min-w-4 text-center">
                          {qty}
                        </span>
                        <button
                          onClick={() => onAddToCart(product, 1)}
                          className="w-6 h-6 rounded-md bg-orange-500 text-white font-bold flex items-center justify-center hover:bg-orange-600 active:scale-95 transition-all"
                          aria-label="Sumar uno"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => onAddToCart(product, 1)}
                        className="bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white text-xs font-bold py-1.5 px-3 rounded-lg flex items-center gap-1.5 transition-all shadow-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Añadir</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
