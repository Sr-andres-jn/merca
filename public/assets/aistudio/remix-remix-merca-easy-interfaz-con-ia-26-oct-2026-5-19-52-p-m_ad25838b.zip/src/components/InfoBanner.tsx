import React from 'react';
import { Sparkles, ArrowRight, ShieldCheck, HeartHandshake, Zap, ShoppingBag } from 'lucide-react';

interface InfoBannerProps {
  onPedirYa: () => void;
  onOpenAi: () => void;
  onExploreMarkets: () => void;
}

export const InfoBanner: React.FC<InfoBannerProps> = ({
  onPedirYa,
  onOpenAi,
  onExploreMarkets,
}) => {
  return (
    <div className="bg-white rounded-2xl border-2 border-[#f97316] p-5 sm:p-6 shadow-xs relative overflow-hidden flex flex-col justify-between">
      {/* Background soft glow */}
      <div className="absolute top-0 right-0 w-44 h-44 bg-orange-100 rounded-full blur-3xl -mr-12 -mt-12 pointer-events-none opacity-60" />

      <div>
        {/* Card Header exactly matching the Figma card */}
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-8 h-8 rounded-full bg-orange-100 text-[#ea580c] flex items-center justify-center font-black text-sm border border-orange-200">
            ?
          </div>
          <h2 className="font-extrabold text-[#ea580c] text-xl sm:text-2xl tracking-tight">
            ¿Qué es MERCA EASY?
          </h2>
        </div>

        {/* Narrative Copy in warm orange/charcoal tones from mockup */}
        <p className="text-gray-800 text-sm sm:text-base leading-relaxed mb-4 font-medium">
          Tu mercado tradicional llevado a tu puerta con <strong className="text-[#ea580c] font-black">Inteligencia Artificial</strong>. ¡Pide lo más fresco directo del campo y de la plaza a precio justo!
        </p>

        {/* Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-5 text-xs">
          <div className="bg-[#fff7ed] p-2.5 rounded-xl border border-orange-200/60 flex items-start gap-2">
            <Zap className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-gray-900">Precios de Plaza</p>
              <p className="text-gray-600 text-[11px]">Hasta 40% más económico que supermercados de cadena.</p>
            </div>
          </div>

          <div className="bg-[#f0fdf4] p-2.5 rounded-xl border border-emerald-200/60 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-gray-900">Frescura Directa</p>
              <p className="text-gray-600 text-[11px]">Cosechado de madrugada sin días en cámaras frías.</p>
            </div>
          </div>

          <div className="bg-[#fefce8] p-2.5 rounded-xl border border-amber-200/60 flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-gray-900">Asistente IA</p>
              <p className="text-gray-600 text-[11px]">Recetas criollas, pesaje exacto y combos inteligentes.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Fresh illustration banner in the center */}
      <div className="my-2 p-3 bg-gradient-to-r from-[#fff7ed] to-[#fff1e6] border border-[#fed7aa] rounded-xl flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="text-3xl select-none" role="img" aria-label="canasta">
            🧺
          </span>
          <div className="text-xs">
            <p className="font-black text-gray-900">Directo de Campesinos y Puesteros</p>
            <p className="text-gray-600 text-[11px]">
              Pesaje transparente y garantía total de satisfacción en cada entrega.
            </p>
          </div>
        </div>

        <button
          onClick={onExploreMarkets}
          className="hidden sm:flex text-xs font-bold text-orange-600 hover:text-orange-700 items-center gap-1 shrink-0 bg-white px-3 py-1.5 rounded-lg border border-orange-200 shadow-2xs hover:bg-orange-50"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>Ver Plazas</span>
        </button>
      </div>

      {/* Prominent Action Buttons matching the Figma "PEDIR YA" button */}
      <div className="pt-3 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
        <button
          onClick={onPedirYa}
          className="flex-1 bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white font-black py-3.5 px-6 rounded-xl shadow-md hover:shadow-lg transition-all text-sm sm:text-base flex items-center justify-center gap-2 group tracking-wide"
        >
          <span>PEDIR YA</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
        </button>

        <button
          onClick={onOpenAi}
          className="bg-amber-100 hover:bg-amber-200 active:bg-amber-300 text-amber-950 font-extrabold py-3.5 px-5 rounded-xl border border-amber-300 transition-colors text-xs sm:text-sm flex items-center justify-center gap-1.5"
        >
          <Sparkles className="w-4 h-4 text-amber-600 fill-amber-400" />
          <span>Consultar al Asistente IA</span>
        </button>
      </div>
    </div>
  );
};
