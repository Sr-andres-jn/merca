import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, X, Send, Bot, User, Plus, Check, ShoppingBag, Loader2 } from 'lucide-react';
import { Product, CartItem, AiChatMessage } from '../types';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  currentMarketId: string;
  onAddToCart: (product: Product, qty?: number) => void;
  initialPrompt?: string;
}

const DEFAULT_PROMPTS = [
  '🍲 ¿Qué necesito para preparar un Ajiaco con $35.000?',
  '💰 Arma un mercado básico de frutas y verduras con $25.000',
  '🥑 ¿Cuál mercado tiene el mejor aguacate hoy?',
  '🍳 Desayuno campesino alto en proteína y energía',
];

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({
  isOpen,
  onClose,
  cart,
  currentMarketId,
  onAddToCart,
  initialPrompt,
}) => {
  const [messages, setMessages] = useState<AiChatMessage[]>([
    {
      id: 'welcome-1',
      role: 'assistant',
      content:
        '¡Hola vecino! 👋 Soy el Asistente IA de Merca Easy. Te ayudo a encontrar lo más fresco de la plaza, armar recetas típicas, comparar precios o ajustarnos a tu presupuesto en Pesos Colombianos (COP). ¿Qué deseas cocinar o comprar hoy?',
      timestamp: 'Ahora',
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [addedProductIds, setAddedProductIds] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [isOpen, messages, isLoading]);

  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleSendMessage(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputValue.trim();
    if (!text || isLoading) return;

    const userMessage: AiChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: messages.slice(-4).map((m) => ({ role: m.role, content: m.content })),
          currentCart: cart.map((c) => ({ id: c.product.id, name: c.product.name, qty: c.quantity })),
          currentMarketId,
        }),
      });

      const data = await response.json();

      if (data.success) {
        const assistantMsg: AiChatMessage = {
          id: `ai-${Date.now()}`,
          role: 'assistant',
          content: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestedProducts: data.suggestedProducts,
          estimatedBudget: data.estimatedBudget,
        };
        setMessages((prev) => [...prev, assistantMsg]);
      } else {
        throw new Error(data.error || 'Error al comunicarse con la IA');
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          content: 'Vecino, hubo un pequeño tropiezo con la red, pero te recomiendo revisar el Mercado Central o Feria Campesina para lo más fresco de la jornada.',
          timestamp: 'Ahora',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddProduct = (product: Product) => {
    onAddToCart(product, 1);
    setAddedProductIds((prev) => [...prev, product.id]);
    setTimeout(() => {
      setAddedProductIds((prev) => prev.filter((id) => id !== product.id));
    }, 2000);
  };

  const handleAddAllSuggested = (products: Product[]) => {
    products.forEach((p) => onAddToCart(p, 1));
    const ids = products.map((p) => p.id);
    setAddedProductIds((prev) => [...prev, ...ids]);
    setTimeout(() => {
      setAddedProductIds([]);
    }, 2500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white w-full max-w-2xl h-[90vh] max-h-[720px] rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-orange-200">
        {/* Header */}
        <div className="bg-[#f97316] text-white p-3.5 sm:p-4 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-xs">
              <Sparkles className="w-5 h-5 text-amber-300 fill-amber-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg leading-tight flex items-center gap-2">
                Asistente Merca AI
                <span className="text-[10px] bg-amber-400 text-orange-950 font-bold px-2 py-0.2 rounded-full">
                  Gemini 3.8
                </span>
              </h3>
              <p className="text-xs text-orange-100">
                Experto en plazas de mercado, recetas criollas y ahorro
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Cerrar modal de IA"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-amber-50/20">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-7 h-7 rounded-full bg-orange-500 text-white flex items-center justify-center shrink-0 text-xs font-bold shadow-xs">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-3 sm:p-4 text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-[#ea580c] text-white rounded-tr-xs'
                      : 'bg-white border border-orange-100 text-gray-800 shadow-xs rounded-tl-xs'
                  }`}
                >
                  <div className="whitespace-pre-line">{msg.content}</div>

                  {/* Suggested Products Card Tray */}
                  {msg.suggestedProducts && msg.suggestedProducts.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-orange-100">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-bold text-xs text-orange-800 flex items-center gap-1">
                          <ShoppingBag className="w-3.5 h-3.5 text-orange-600" />
                          Productos recomendados del catálogo ({msg.suggestedProducts.length}):
                        </span>
                        <button
                          onClick={() => handleAddAllSuggested(msg.suggestedProducts!)}
                          className="text-[11px] font-bold text-orange-600 hover:text-orange-700 bg-orange-50 px-2 py-0.5 rounded-md hover:bg-orange-100 transition-colors"
                        >
                          Añadir todos (+${msg.estimatedBudget?.toLocaleString('es-CO') || ''})
                        </button>
                      </div>

                      <div className="space-y-1.5">
                        {msg.suggestedProducts.map((p) => {
                          const wasAdded = addedProductIds.includes(p.id);
                          return (
                            <div
                              key={p.id}
                              className="bg-orange-50/60 p-2 rounded-xl border border-orange-200/60 flex items-center justify-between gap-2"
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                <img
                                  src={p.image}
                                  alt={p.name}
                                  className="w-10 h-10 rounded-lg object-cover shrink-0"
                                />
                                <div className="min-w-0">
                                  <p className="font-bold text-xs text-gray-900 truncate">
                                    {p.name}
                                  </p>
                                  <p className="text-[11px] text-gray-500 truncate">
                                    {p.stallName} · {p.marketName}
                                  </p>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0">
                                <span className="text-xs font-bold text-gray-900">
                                  ${p.price.toLocaleString('es-CO')}
                                </span>
                                <button
                                  onClick={() => handleAddProduct(p)}
                                  className={`p-1.5 rounded-lg text-xs font-semibold flex items-center justify-center transition-all ${
                                    wasAdded
                                      ? 'bg-emerald-600 text-white'
                                      : 'bg-orange-500 hover:bg-orange-600 text-white'
                                  }`}
                                  title="Añadir a la canasta"
                                >
                                  {wasAdded ? (
                                    <Check className="w-3.5 h-3.5" />
                                  ) : (
                                    <Plus className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <span className={`block text-[10px] mt-1 text-right ${isUser ? 'text-orange-200' : 'text-gray-400'}`}>
                    {msg.timestamp}
                  </span>
                </div>

                {isUser && (
                  <div className="w-7 h-7 rounded-full bg-gray-700 text-white flex items-center justify-center shrink-0 text-xs font-bold">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-orange-600 bg-white p-3 rounded-2xl w-fit border border-orange-100 shadow-xs">
              <Loader2 className="w-4 h-4 animate-spin text-orange-500" />
              <span>Consultando los puestos de mercado y calculando precios...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Prompts Chips */}
        <div className="px-3 pt-2 bg-gray-50 border-t border-gray-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {DEFAULT_PROMPTS.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(prompt)}
              className="text-[11px] whitespace-nowrap bg-white hover:bg-orange-50 text-gray-700 hover:text-orange-600 border border-gray-200 rounded-full px-2.5 py-1 font-medium transition-colors"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-gray-50 border-t border-gray-200 flex items-center gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSendMessage();
            }}
            placeholder="Pregunta por recetas, ingredientes o presupuesto..."
            className="flex-1 bg-white border border-gray-300 rounded-xl px-3.5 py-2 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 placeholder:text-gray-400"
            disabled={isLoading}
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={!inputValue.trim() || isLoading}
            className="bg-[#f97316] hover:bg-orange-600 disabled:opacity-50 text-white p-2.5 rounded-xl font-bold transition-all shrink-0"
            aria-label="Enviar mensaje a la IA"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
