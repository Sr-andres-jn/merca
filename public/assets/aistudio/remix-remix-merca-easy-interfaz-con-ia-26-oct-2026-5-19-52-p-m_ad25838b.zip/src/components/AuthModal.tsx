import React, { useState } from 'react';
import {
  X,
  Mail,
  Lock,
  Phone,
  Eye,
  EyeOff,
  User,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  ShieldCheck,
  Send,
  RefreshCw,
} from 'lucide-react';
import { AuthUser } from '../types';

export type AuthMode = 'login' | 'register' | 'forgot_password' | 'verify_code' | 'reset_success';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: AuthUser) => void;
  initialMode?: AuthMode;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  initialMode = 'login',
}) => {
  const [mode, setMode] = useState<AuthMode>(initialMode);

  // Form Fields
  const [fullName, setFullName] = useState('');
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(true);

  // Password Reset flow fields
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [resendTimer, setResendTimer] = useState(0);

  // Status & Feedback
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  // Reset fields on mode switch
  const switchMode = (newMode: AuthMode) => {
    setMode(newMode);
    setErrorMsg(null);
  };

  // Helper validation
  const validateEmailOrPhone = (input: string) => {
    const trimmed = input.trim();
    if (!trimmed) return false;
    const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed);
    const isPhone = /^[0-9+\s-]{7,15}$/.test(trimmed);
    return isEmail || isPhone;
  };

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!validateEmailOrPhone(emailOrPhone)) {
      setErrorMsg('Por favor ingresa un correo electrónico válido o número de teléfono');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const isEmail = emailOrPhone.includes('@');
      const user: AuthUser = {
        id: `usr-${Date.now().toString().slice(-5)}`,
        name: isEmail ? emailOrPhone.split('@')[0] : 'Usuario Merca Easy',
        emailOrPhone: emailOrPhone.trim(),
        avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80`,
        provider: 'email',
      };
      onLoginSuccess(user);
      onClose();
    }, 600);
  };

  // Handle Register
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!fullName.trim()) {
      setErrorMsg('Por favor ingresa tu nombre completo');
      return;
    }
    if (!validateEmailOrPhone(emailOrPhone)) {
      setErrorMsg('Por favor ingresa un correo electrónico o teléfono válido');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('La contraseña debe tener mínimo 6 caracteres');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg('Las contraseñas no coinciden');
      return;
    }
    if (!agreeTerms) {
      setErrorMsg('Debes aceptar los términos y condiciones de Merca Easy');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const user: AuthUser = {
        id: `usr-${Date.now().toString().slice(-5)}`,
        name: fullName.trim(),
        emailOrPhone: emailOrPhone.trim(),
        avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80`,
        provider: 'email',
      };
      onLoginSuccess(user);
      onClose();
    }, 700);
  };

  // Handle Request Forgot Password Code
  const handleRequestResetCode = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!validateEmailOrPhone(emailOrPhone)) {
      setErrorMsg('Ingresa el correo electrónico o teléfono de tu cuenta');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      // Pre-fill a demo code for convenience
      setResetCode('849216');
      setResendTimer(30);
      switchMode('verify_code');
    }, 600);
  };

  // Handle Reset Password Submit
  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!resetCode.trim() || resetCode.length < 4) {
      setErrorMsg('Ingresa el código de 6 dígitos que enviamos a tu correo');
      return;
    }
    if (newPassword.length < 6) {
      setErrorMsg('La nueva contraseña debe tener mínimo 6 caracteres');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setErrorMsg('Las nuevas contraseñas no coinciden');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      switchMode('reset_success');
    }, 600);
  };

  // Social Login (Google & Apple)
  const handleSocialLogin = (provider: 'google' | 'apple') => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const user: AuthUser = {
        id: `usr-${Date.now().toString().slice(-5)}`,
        name: provider === 'google' ? 'Usuario Google' : 'Usuario Apple',
        emailOrPhone: provider === 'google' ? 'usuario.google@gmail.com' : 'usuario.apple@icloud.com',
        avatar:
          provider === 'google'
            ? 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80'
            : 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80',
        provider,
      };
      onLoginSuccess(user);
      onClose();
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-orange-200 flex flex-col max-h-[92vh]">
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-[#f97316] to-[#ea580c] text-white p-5 relative select-none">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-black/10 hover:bg-black/20 text-white transition-colors"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 bg-white/20 rounded-xl backdrop-blur-xs text-white">
              🛒
            </span>
            <span className="font-extrabold text-sm tracking-wider uppercase text-orange-100">
              MERCA EASY!
            </span>
          </div>

          <h3 className="font-black text-xl sm:text-2xl tracking-tight">
            {mode === 'login' && 'Iniciar Sesión'}
            {mode === 'register' && 'Crear Cuenta'}
            {mode === 'forgot_password' && 'Recuperar Contraseña'}
            {mode === 'verify_code' && 'Restablecer Clave'}
            {mode === 'reset_success' && '¡Clave Actualizada!'}
          </h3>
          <p className="text-xs text-orange-100 mt-0.5">
            {mode === 'login' && 'Accede a tus mercados favoritos y pedidos con IA'}
            {mode === 'register' && 'Regístrate para comprar directo de la plaza y el campo'}
            {mode === 'forgot_password' && 'Te enviaremos un código de confirmación a tu correo'}
            {mode === 'verify_code' && `Verificando cuenta: ${emailOrPhone || 'tu correo'}`}
            {mode === 'reset_success' && 'Ahora puedes entrar con tu nueva contraseña'}
          </p>
        </div>

        {/* Form Body with Smooth Scrolling */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 flex-1 bg-white">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2 animate-shake">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* ================= MODE: LOGIN ================= */}
          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-3.5">
              {/* Correo o Teléfono */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Correo electrónico o número de teléfono
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={emailOrPhone}
                    onChange={(e) => setEmailOrPhone(e.target.value)}
                    placeholder="ejemplo@correo.com o 310 123 4567"
                    className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all placeholder:text-gray-400 font-medium"
                  />
                </div>
              </div>

              {/* Contraseña */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-gray-700">
                    Contraseña
                  </label>
                  <button
                    type="button"
                    onClick={() => switchMode('forgot_password')}
                    className="text-[11px] font-bold text-orange-600 hover:text-orange-700 hover:underline transition-colors"
                  >
                    ¿Olvidó su contraseña?
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Ingresa tu contraseña"
                    className="w-full pl-9 pr-10 py-2.5 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all placeholder:text-gray-400 font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Botón Iniciar Sesión */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white font-extrabold py-3 px-4 rounded-xl shadow-md transition-all text-sm flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>Iniciar Sesión</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              {/* Divisor */}
              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-200" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="px-3 bg-white text-gray-400 font-semibold uppercase text-[10px] tracking-wider">
                    o continuar con
                  </span>
                </div>
              </div>

              {/* Botones Sociales (Google y Apple) */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => handleSocialLogin('google')}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-xs font-bold text-gray-700 transition-all shadow-2xs"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.97 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>Google</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSocialLogin('apple')}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-xs font-bold text-gray-800 transition-all shadow-2xs"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 170 170">
                    <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.74 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.06-7.7-7.94-12.03-14.65-6.19-9.66-11.02-20.73-14.49-33.22-3.47-12.48-5.21-23.75-5.21-33.8 0-14.54 3.59-26.68 10.77-36.42 7.18-9.74 16.48-14.74 27.88-15.01 5.35 0 11.22 1.34 17.62 4.02 6.4 2.68 10.15 4.09 11.24 4.23 1.93-.3 5.86-1.74 11.79-4.33 5.93-2.58 11.53-3.8 16.8-3.65 12.63.63 22.84 4.88 30.64 12.77-10.98 6.64-16.32 15.82-16.03 27.53.28 9.3 3.86 17.07 10.74 23.3 6.89 6.24 15.22 9.87 25 10.9-1.93 6.07-4.27 12.22-7.01 18.45zm-39.77-109.1c0-7.37 2.64-14.18 7.92-20.44 5.28-6.26 11.72-10.02 19.32-11.28.28 1.19.42 2.37.42 3.54 0 7.37-2.73 14.36-8.2 20.97-5.46 6.61-12.01 10.45-19.64 11.53-.13-1.45-.19-2.88-.19-4.32z" />
                  </svg>
                  <span>Apple</span>
                </button>
              </div>

              {/* Registro Footer */}
              <div className="pt-3 text-center text-xs text-gray-600">
                <span>¿No estás registrado? </span>
                <button
                  type="button"
                  onClick={() => switchMode('register')}
                  className="font-extrabold text-[#ea580c] hover:underline"
                >
                  Regístrate aquí
                </button>
              </div>
            </form>
          )}

          {/* ================= MODE: REGISTER ================= */}
          {mode === 'register' && (
            <form onSubmit={handleRegister} className="space-y-3">
              {/* Nombre completo */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Nombre completo
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Ej. Carlos Martínez"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all font-medium"
                  />
                </div>
              </div>

              {/* Correo o Teléfono */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Correo electrónico o número de teléfono
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={emailOrPhone}
                    onChange={(e) => setEmailOrPhone(e.target.value)}
                    placeholder="ejemplo@correo.com o 310 123 4567"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all font-medium"
                  />
                </div>
              </div>

              {/* Contraseña */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Contraseña (mínimo 6 caracteres)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Crea una contraseña segura"
                    className="w-full pl-9 pr-10 py-2 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirmar Contraseña */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Confirmar contraseña
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repite tu contraseña"
                    className="w-full pl-9 pr-10 py-2 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                    tabIndex={-1}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Checkbox Términos */}
              <label className="flex items-start gap-2 pt-1 text-xs text-gray-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="rounded text-orange-600 focus:ring-orange-500 mt-0.5"
                />
                <span className="text-[11px] leading-snug">
                  Acepto los términos de servicio, política de privacidad y entrega de productos frescos de plaza.
                </span>
              </label>

              {/* Botón Registrarse */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white font-extrabold py-3 px-4 rounded-xl shadow-md transition-all text-sm flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>Registrarse</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              {/* Divisor */}
              <div className="relative my-3">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-200" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="px-3 bg-white text-gray-400 font-semibold uppercase text-[10px] tracking-wider">
                    o registrarse con
                  </span>
                </div>
              </div>

              {/* Social buttons */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => handleSocialLogin('google')}
                  className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl border border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-xs font-bold text-gray-700 transition-all shadow-2xs"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.97 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>Google</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSocialLogin('apple')}
                  className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl border border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-xs font-bold text-gray-800 transition-all shadow-2xs"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 170 170">
                    <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.74 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.06-7.7-7.94-12.03-14.65-6.19-9.66-11.02-20.73-14.49-33.22-3.47-12.48-5.21-23.75-5.21-33.8 0-14.54 3.59-26.68 10.77-36.42 7.18-9.74 16.48-14.74 27.88-15.01 5.35 0 11.22 1.34 17.62 4.02 6.4 2.68 10.15 4.09 11.24 4.23 1.93-.3 5.86-1.74 11.79-4.33 5.93-2.58 11.53-3.8 16.8-3.65 12.63.63 22.84 4.88 30.64 12.77-10.98 6.64-16.32 15.82-16.03 27.53.28 9.3 3.86 17.07 10.74 23.3 6.89 6.24 15.22 9.87 25 10.9-1.93 6.07-4.27 12.22-7.01 18.45zm-39.77-109.1c0-7.37 2.64-14.18 7.92-20.44 5.28-6.26 11.72-10.02 19.32-11.28.28 1.19.42 2.37.42 3.54 0 7.37-2.73 14.36-8.2 20.97-5.46 6.61-12.01 10.45-19.64 11.53-.13-1.45-.19-2.88-.19-4.32z" />
                  </svg>
                  <span>Apple</span>
                </button>
              </div>

              {/* Login link */}
              <div className="pt-2 text-center text-xs text-gray-600">
                <span>¿Ya tienes cuenta? </span>
                <button
                  type="button"
                  onClick={() => switchMode('login')}
                  className="font-extrabold text-[#ea580c] hover:underline"
                >
                  Inicia sesión aquí
                </button>
              </div>
            </form>
          )}

          {/* ================= MODE: FORGOT PASSWORD ================= */}
          {mode === 'forgot_password' && (
            <form onSubmit={handleRequestResetCode} className="space-y-4">
              <div className="bg-orange-50 border border-orange-200/80 rounded-2xl p-3.5 text-xs text-orange-950 flex items-start gap-2.5">
                <KeyRound className="w-5 h-5 text-orange-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  Ingresa el correo electrónico o número telefónico registrado en tu cuenta. Te enviaremos un código de confirmación de 6 dígitos para que puedas crear una nueva contraseña.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Correo electrónico o teléfono registrado
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={emailOrPhone}
                    onChange={(e) => setEmailOrPhone(e.target.value)}
                    placeholder="ejemplo@correo.com o 310 123 4567"
                    className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all font-medium"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white font-extrabold py-3 px-4 rounded-xl shadow-md transition-all text-sm flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Enviar código de confirmación</span>
                  </>
                )}
              </button>

              <div className="pt-2 text-center text-xs">
                <button
                  type="button"
                  onClick={() => switchMode('login')}
                  className="font-bold text-gray-600 hover:text-orange-600"
                >
                  ← Volver a Iniciar Sesión
                </button>
              </div>
            </form>
          )}

          {/* ================= MODE: VERIFY CODE & NEW PASSWORD ================= */}
          {mode === 'verify_code' && (
            <form onSubmit={handleResetPassword} className="space-y-3.5">
              <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-3 text-xs text-emerald-900 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Código enviado exitosamente</p>
                  <p className="text-[11px] text-emerald-800">
                    Revisa tu bandeja de entrada o SMS en: <strong>{emailOrPhone}</strong>
                  </p>
                </div>
              </div>

              {/* Código de confirmación */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-gray-700">
                    Código de confirmación de 6 dígitos
                  </label>
                  <span className="text-[10px] text-orange-600 font-semibold">
                    (Demo: 849216)
                  </span>
                </div>
                <input
                  type="text"
                  maxLength={6}
                  required
                  value={resetCode}
                  onChange={(e) => setResetCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="849216"
                  className="w-full py-2.5 px-3 text-center tracking-widest text-lg font-black bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all text-orange-950"
                />
              </div>

              {/* Nueva Contraseña */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Nueva contraseña (mínimo 6 caracteres)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Escribe tu nueva clave"
                    className="w-full pl-9 pr-10 py-2.5 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirmar Nueva Contraseña */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Confirmar nueva contraseña
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    placeholder="Repite la nueva clave"
                    className="w-full pl-9 pr-10 py-2.5 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                    tabIndex={-1}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white font-extrabold py-3 px-4 rounded-xl shadow-md transition-all text-sm flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <KeyRound className="w-4 h-4" />
                    <span>Realizar Nueva Contraseña</span>
                  </>
                )}
              </button>

              <div className="flex items-center justify-between pt-1 text-xs text-gray-500">
                <button
                  type="button"
                  onClick={() => switchMode('forgot_password')}
                  className="font-medium hover:text-orange-600"
                >
                  Cambiar correo/teléfono
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setErrorMsg(null);
                    setResetCode('849216');
                    alert('Código de confirmación reenviado: 849216');
                  }}
                  className="font-bold text-orange-600 hover:underline"
                >
                  Reenviar código
                </button>
              </div>
            </form>
          )}

          {/* ================= MODE: RESET SUCCESS ================= */}
          {mode === 'reset_success' && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h4 className="font-black text-gray-900 text-lg">
                  ¡Contraseña actualizada con éxito!
                </h4>
                <p className="text-xs text-gray-600 mt-1 max-w-xs mx-auto">
                  Tu cuenta ha sido protegida y tu nueva contraseña ya se encuentra activa.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setPassword(newPassword);
                  switchMode('login');
                }}
                className="w-full bg-[#f97316] hover:bg-[#ea580c] text-white font-extrabold py-3 px-4 rounded-xl shadow-md text-sm transition-all"
              >
                Iniciar Sesión con mi Nueva Clave
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
