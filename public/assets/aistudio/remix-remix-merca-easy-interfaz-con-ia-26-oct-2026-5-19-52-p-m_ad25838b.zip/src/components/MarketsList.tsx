import React from 'react';
import { Store, MapPin, Users, Star, Clock, CheckCircle2, ChevronRight } from 'lucide-react';
import { Market } from '../types';

interface MarketsListProps {
  markets: Market[];
  selectedMarketId: string;
  onSelectMarket: (marketId: string) => void;
  onExploreProducts: () => void;
}

export const MarketsList: React.FC<MarketsListProps> = ({
  markets,
  selectedMarketId,
  onSelectMarket,
  onExploreProducts,
}) => {
  return (
    <div className="space-y-3">
      {/* Section Header exactly as in Figma Mockup */}
      <div className="flex items-center justify-between pb-1">
        <div className="flex items-center gap-2">
          {/* Small orange market stall icon */}
          <span className="text-orange-500 font-bold text-lg select-none" role="img" aria-label="mercado">
            🏪
          </span>
          <h2 className="font-extrabold text-gray-900 text-base sm:text-lg tracking-tight">
            Mercados Disponibles
          </h2>
        </div>

        <button
          onClick={() => onSelectMarket('todos')}
          className={`text-xs font-bold px-2.5 py-1 rounded-md transition-colors ${
            selectedMarketId === 'todos'
              ? 'bg-[#f97316] text-white shadow-xs'
              : 'text-orange-600 hover:bg-orange-100/60'
          }`}
        >
          Ver Todos
        </button>
      </div>

      {/* Market Cards with identical Figma styling */}
      <div className="space-y-2.5">
        {markets.map((market) => {
          const isSelected = selectedMarketId === market.id;
          const isOpen = market.status === 'Abierto';

          return (
            <div
              key={market.id}
              onClick={() => onSelectMarket(market.id)}
              className={`group relative p-3.5 rounded-xl border transition-all cursor-pointer text-left ${
                isSelected
                  ? 'bg-[#fff5eb] border-[#f97316] shadow-sm ring-1 ring-orange-300'
                  : 'bg-[#fff8f2] hover:bg-[#fff2e5] border-[#fed7aa] shadow-2xs'
              }`}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  onSelectMarket(market.id);
                }
              }}
            >
              {/* Row 1: Market Name + Status Badge (Green "Abierto" / Red "Cerrado") */}
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-1.5 min-w-0">
                  <h3 className="font-extrabold text-gray-900 text-sm sm:text-base group-hover:text-orange-600 transition-colors truncate">
                    {market.name}
                  </h3>
                  {isSelected && (
                    <CheckCircle2 className="w-4 h-4 text-orange-600 inline shrink-0" />
                  )}
                </div>

                {/* Status Pill Badge exactly as in Mockup */}
                <span
                  className={`text-[11px] font-extrabold px-3 py-0.5 rounded-full shrink-0 tracking-wide ${
                    isOpen
                      ? 'bg-[#d1fae5] text-[#065f46] border border-[#a7f3d0]'
                      : 'bg-[#ffe4e6] text-[#9f1239] border border-[#fecdd3]'
                  }`}
                >
                  {market.status}
                </span>
              </div>

              {/* Row 2: Distance + Vendors Count exactly as in Mockup */}
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-gray-600">
                <span className="flex items-center gap-1 font-semibold text-gray-700">
                  <MapPin className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                  {market.distance}
                </span>
                <span className="text-gray-300 font-bold">·</span>
                <span className="flex items-center gap-1 text-gray-600 font-medium">
                  <Users className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                  {market.vendorsCount} vendedores
                </span>
                <span className="text-gray-300 hidden sm:inline">·</span>
                <span className="hidden sm:flex items-center gap-1 text-amber-700 font-semibold text-[11px]">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                  {market.rating}
                </span>
              </div>

              {/* Expansion with action when active */}
              {isSelected && (
                <div className="mt-2.5 pt-2 border-t border-orange-200/80 text-xs text-gray-600 space-y-1.5 animate-fadeIn">
                  <p className="line-clamp-2 text-gray-700 leading-relaxed">{market.description}</p>
                  <div className="flex items-center justify-between text-[11px] pt-1">
                    <span className="flex items-center gap-1 text-gray-500">
                      <Clock className="w-3 h-3 text-orange-500" />
                      {market.hours}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onExploreProducts();
                      }}
                      className="font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 bg-white px-2.5 py-1 rounded-md border border-orange-200 shadow-2xs hover:bg-orange-50"
                    >
                      <span>Ver puestos y productos</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
