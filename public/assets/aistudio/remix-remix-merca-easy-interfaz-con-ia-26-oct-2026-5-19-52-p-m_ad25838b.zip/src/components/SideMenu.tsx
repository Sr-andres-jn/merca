import {
  X,
  Store,
  Sparkles,
  ShoppingBag,
  Heart,
  Shield,
  HelpCircle,
  MapPin,
  LogIn,
  UserPlus,
  LogOut,
  User,
  Database,
} from 'lucide-react';
import { AuthUser } from '../types';

interface SideMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAi: () => void;
  onSelectMarket: (marketId: string) => void;
  selectedCity: string;
  onSelectCity: (city: string) => void;
  user: AuthUser | null;
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onLogout: () => void;
  onOpenDatabase?: () => void;
}

export const SideMenu: React.FC<SideMenuProps> = ({
  isOpen,
  onClose,
  onOpenAi,
  onSelectMarket,
  selectedCity,
  onSelectCity,
  user,
  onOpenAuth,
  onLogout,
  onOpenDatabase,
}) => {
  if (!isOpen) return null;

  const CITIES = [
    'Madrid, Cundinamarca (Centro / Parque Principal)',
    'Madrid - La Prosperidad',
    'Madrid - Hacienda Los Alcaparros',
    'Madrid - Barrio San José / Loreto',
    'Madrid - Sosiego / El Cortijo',
    'Madrid - Vereda Puente de Piedra',
    'Madrid - Vereda Chueca / El Corzo',
    'Madrid - Vereda Moyano / Carrasquilla',
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
      />

      <div className="fixed inset-y-0 left-0 max-w-full flex pr-10">
        <div className="w-screen max-w-xs bg-white shadow-2xl flex flex-col justify-between">
          <div className="overflow-y-auto">
            {/* Header */}
            <div className="bg-[#f97316] text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Store className="w-5 h-5 text-amber-200" />
                <span className="font-extrabold text-lg tracking-wide">MERCA EASY!</span>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-md text-white/80 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* User Profile Card Section */}
            <div className="p-4 border-b border-orange-100 bg-orange-50/70">
              {user ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120'}
                      alt={user.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-orange-400 shadow-xs"
                    />
                    <div className="min-w-0 flex-1">
                      <h4 className="font-black text-gray-900 text-sm truncate">
                        {user.name}
                      </h4>
                      <p className="text-[11px] text-gray-500 truncate">
                        {user.emailOrPhone}
                      </p>
                      <span className="inline-block mt-0.5 text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.2 rounded-full">
                        Cuenta Verificada
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onLogout();
                      onClose();
                    }}
                    className="w-full py-1.5 px-3 bg-white hover:bg-rose-50 text-rose-600 border border-rose-200 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Cerrar Sesión</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-8 h-8 rounded-full bg-orange-200 text-orange-700 flex items-center justify-center">
                      <User className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-extrabold text-xs text-gray-900">Bienvenido a Merca Easy</p>
                      <p className="text-[11px] text-gray-500">Inicia sesión o crea tu cuenta</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      onClick={() => {
                        onClose();
                        onOpenAuth('login');
                      }}
                      className="w-full bg-[#f97316] hover:bg-[#ea580c] text-white text-xs font-black py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 shadow-2xs"
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      <span>Ingresar</span>
                    </button>

                    <button
                      onClick={() => {
                        onClose();
                        onOpenAuth('register');
                      }}
                      className="w-full bg-white hover:bg-orange-50 text-orange-700 border border-orange-300 text-xs font-bold py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 shadow-2xs"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Registrarse</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* City Selector */}
            <div className="p-3 border-b border-gray-100 bg-gray-50/50">
              <label className="block text-[11px] font-bold uppercase text-orange-900 mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-orange-600" />
                <span>Zona de entrega</span>
              </label>
              <select
                value={selectedCity}
                onChange={(e) => onSelectCity(e.target.value)}
                className="w-full text-xs font-semibold bg-white border border-gray-200 rounded-lg p-2 text-gray-800 focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                {CITIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Navigation links */}
            <nav className="p-3 space-y-1 text-xs font-bold text-gray-700">
              <button
                onClick={() => {
                  onSelectMarket('todos');
                  onClose();
                }}
                className="w-full text-left p-2.5 rounded-xl hover:bg-orange-50 hover:text-orange-600 flex items-center gap-2.5 transition-colors"
              >
                <Store className="w-4 h-4 text-orange-500" />
                <span>Explorar Plazas de Mercado</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenAi();
                }}
                className="w-full text-left p-2.5 rounded-xl bg-orange-100/60 text-orange-900 hover:bg-orange-100 flex items-center gap-2.5 transition-colors font-black"
              >
                <Sparkles className="w-4 h-4 text-orange-600 fill-orange-400" />
                <span>Asistente de Compras con IA</span>
              </button>

              <button
                onClick={() => {
                  onSelectMarket('feria-campesina');
                  onClose();
                }}
                className="w-full text-left p-2.5 rounded-xl hover:bg-orange-50 hover:text-orange-600 flex items-center gap-2.5 transition-colors"
              >
                <ShoppingBag className="w-4 h-4 text-emerald-600" />
                <span>Feria Campesina Directa</span>
              </button>

              <button
                onClick={() => onClose()}
                className="w-full text-left p-2.5 rounded-xl hover:bg-orange-50 hover:text-orange-600 flex items-center gap-2.5 transition-colors"
              >
                <Heart className="w-4 h-4 text-rose-500" />
                <span>Mis Puestos Favoritos</span>
              </button>

              {onOpenDatabase && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenDatabase();
                  }}
                  className="w-full text-left p-2.5 rounded-xl bg-gray-100 hover:bg-orange-50 text-gray-800 hover:text-orange-900 flex items-center justify-between transition-colors border border-gray-200/80"
                >
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-orange-600" />
                    <span>Base de Datos</span>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-black">
                    Persistente
                  </span>
                </button>
              )}

              <div className="pt-2 my-1 border-t border-gray-100" />

              <div className="px-2.5 text-[10px] font-bold uppercase text-gray-400 tracking-wider">
                Garantía y Ayuda
              </div>

              <button
                onClick={() => onClose()}
                className="w-full text-left p-2 rounded-xl hover:bg-orange-50 hover:text-orange-600 flex items-center gap-2.5 transition-colors text-xs font-medium text-gray-600"
              >
                <Shield className="w-4 h-4 text-gray-400" />
                <span>Garantía de Frescura & Pesaje</span>
              </button>

              <button
                onClick={() => onClose()}
                className="w-full text-left p-2 rounded-xl hover:bg-orange-50 hover:text-orange-600 flex items-center gap-2.5 transition-colors text-xs font-medium text-gray-600"
              >
                <HelpCircle className="w-4 h-4 text-gray-400" />
                <span>¿Cómo funciona el regateo IA?</span>
              </button>
            </nav>
          </div>

          {/* Footer in side menu */}
          <div className="p-3.5 border-t border-gray-100 bg-gray-50 text-[11px] text-gray-500 space-y-0.5">
            <p className="font-bold text-gray-800">MERCA EASY! Mobile v1.2</p>
            <p>Conectando el campo con la ciudad con Gemini AI.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
