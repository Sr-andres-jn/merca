import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';

interface AiFloatingButtonProps {
  onClick: () => void;
}

export const AiFloatingButton: React.FC<AiFloatingButtonProps> = ({ onClick }) => {
  return (
    <div className="fixed bottom-5 right-5 z-40">
      <button
        onClick={onClick}
        className="group relative flex items-center gap-2 bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white font-extrabold px-5 py-3.5 rounded-full shadow-xl hover:shadow-2xl transition-all transform hover:-translate-y-0.5 active:translate-y-0 border-2 border-white/80"
        title="Crear pedido con Asistente IA"
      >
        <span className="p-1 bg-white/20 rounded-full">
          <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300 animate-pulse" />
        </span>
        <span className="text-sm tracking-wide">PEDIR YA</span>
        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
      </button>
    </div>
  );
};
