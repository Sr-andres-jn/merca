import React, { useState, useEffect } from 'react';
import { X, MapPin, CreditCard, Banknote, ShieldCheck, CheckCircle2, Loader2, Sparkles, User } from 'lucide-react';
import { CartItem, Order, AuthUser } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  user?: AuthUser | null;
  onOrderCompleted: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cart,
  user,
  onOrderCompleted,
}) => {
  const [customerName, setCustomerName] = useState('Alejandro Rodríguez');
  const [address, setAddress] = useState('Calle 7 # 5-40, Barrio San Carlos, Madrid, Cundinamarca');
  const [phone, setPhone] = useState('310 456 7890');
  const [notes, setNotes] = useState('Por favor aguacates que estén listos para hoy y tomates pintones.');
  const [paymentMethod, setPaymentMethod] = useState<'nequi' | 'daviplata' | 'efectivo' | 'tarjeta'>('nequi');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (user) {
      if (user.name) setCustomerName(user.name);
      if (user.phone) setPhone(user.phone);
      else if (!user.emailOrPhone.includes('@')) setPhone(user.emailOrPhone);
    }
  }, [user]);

  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const deliveryFee = 4500;
  const discount = subtotal >= 30000 ? 3000 : 0;
  const total = subtotal + deliveryFee - discount;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart,
          subtotal,
          deliveryFee,
          discount,
          total,
          marketName: cart[0]?.product.marketName || 'Mercado Central',
          customerName,
          address,
          paymentMethod:
            paymentMethod === 'nequi'
              ? 'Nequi (Pago al instante)'
              : paymentMethod === 'daviplata'
              ? 'Daviplata'
              : paymentMethod === 'efectivo'
              ? 'Efectivo contra entrega'
              : 'Tarjeta Débito/Crédito',
        }),
      });

      const data = await response.json();
      if (data.success) {
        onOrderCompleted(data.order);
      } else {
        throw new Error('Error al registrar pedido');
      }
    } catch (err) {
      // Fallback local order
      const mockOrder: Order = {
        id: `ORD-${Math.floor(100000 + Math.random() * 900000)}`,
        createdAt: new Date().toISOString(),
        items: cart,
        subtotal,
        deliveryFee,
        discount,
        total,
        marketName: cart[0]?.product.marketName || 'Mercado Central',
        status: 'preparando',
        customerName,
        address,
        paymentMethod: paymentMethod.toUpperCase(),
      };
      onOrderCompleted(mockOrder);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-orange-200">
        {/* Header */}
        <div className="bg-[#f97316] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-200" />
            <h3 className="font-extrabold text-base">Finalizar Pedido Directo de Plaza</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Customer info */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500">
              Datos de entrega
            </h4>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Nombre completo
              </label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Dirección exacta y detalles
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Teléfono móvil de contacto
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-xs sm:text-sm bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Notas especiales para el puestero / pesador
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ej. 'Plátanos para asar el fin de semana', 'carne picada para estofado'..."
                className="w-full text-xs bg-gray-50 border border-gray-200 rounded-xl p-2.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div className="space-y-2 pt-2 border-t border-gray-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500">
              Método de pago
            </h4>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <label
                className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                  paymentMethod === 'nequi'
                    ? 'border-orange-500 bg-orange-50/70 font-bold text-orange-900'
                    : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'nequi'}
                  onChange={() => setPaymentMethod('nequi')}
                  className="sr-only"
                />
                <span className="w-2.5 h-2.5 rounded-full border border-orange-500 flex items-center justify-center shrink-0">
                  {paymentMethod === 'nequi' && <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />}
                </span>
                <span>📱 Nequi / QR</span>
              </label>

              <label
                className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                  paymentMethod === 'daviplata'
                    ? 'border-orange-500 bg-orange-50/70 font-bold text-orange-900'
                    : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'daviplata'}
                  onChange={() => setPaymentMethod('daviplata')}
                  className="sr-only"
                />
                <span className="w-2.5 h-2.5 rounded-full border border-orange-500 flex items-center justify-center shrink-0">
                  {paymentMethod === 'daviplata' && <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />}
                </span>
                <span>🔴 Daviplata</span>
              </label>

              <label
                className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                  paymentMethod === 'efectivo'
                    ? 'border-orange-500 bg-orange-50/70 font-bold text-orange-900'
                    : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'efectivo'}
                  onChange={() => setPaymentMethod('efectivo')}
                  className="sr-only"
                />
                <span className="w-2.5 h-2.5 rounded-full border border-orange-500 flex items-center justify-center shrink-0">
                  {paymentMethod === 'efectivo' && <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />}
                </span>
                <span className="flex items-center gap-1">
                  <Banknote className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Contra Entrega</span>
                </span>
              </label>

              <label
                className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                  paymentMethod === 'tarjeta'
                    ? 'border-orange-500 bg-orange-50/70 font-bold text-orange-900'
                    : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'tarjeta'}
                  onChange={() => setPaymentMethod('tarjeta')}
                  className="sr-only"
                />
                <span className="w-2.5 h-2.5 rounded-full border border-orange-500 flex items-center justify-center shrink-0">
                  {paymentMethod === 'tarjeta' && <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />}
                </span>
                <span className="flex items-center gap-1">
                  <CreditCard className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Tarjeta</span>
                </span>
              </label>
            </div>
          </div>

          {/* Summary Box */}
          <div className="bg-orange-50/80 rounded-xl p-3 border border-orange-200 text-xs space-y-1 text-gray-700">
            <div className="flex justify-between">
              <span>{cart.length} productos en canasta</span>
              <span>${subtotal.toLocaleString('es-CO')} COP</span>
            </div>
            <div className="flex justify-between">
              <span>Envío motorizado local</span>
              <span>${deliveryFee.toLocaleString('es-CO')} COP</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-emerald-700 font-bold">
                <span>Beneficio Merca Easy</span>
                <span>-${discount.toLocaleString('es-CO')} COP</span>
              </div>
            )}
            <div className="pt-2 border-t border-orange-200 flex justify-between font-black text-sm text-gray-900">
              <span>Total a pagar</span>
              <span className="text-orange-600 text-base">
                ${total.toLocaleString('es-CO')} COP
              </span>
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white font-extrabold py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Confirmando con la plaza...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirmar Orden (${total.toLocaleString('es-CO')} COP)</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
