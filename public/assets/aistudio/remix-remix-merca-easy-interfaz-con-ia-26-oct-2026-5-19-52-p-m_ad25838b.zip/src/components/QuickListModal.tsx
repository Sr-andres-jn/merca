import React from 'react';
import { X, Plus, Check, ShoppingBag, Store, Sparkles } from 'lucide-react';
import { QuickListItem, Product } from '../types';

interface QuickListModalProps {
  list: QuickListItem | null;
  allProducts: Product[];
  onClose: () => void;
  onAddListToCart: (items: { product: Product; quantity: number }[]) => void;
}

export const QuickListModal: React.FC<QuickListModalProps> = ({
  list,
  allProducts,
  onClose,
  onAddListToCart,
}) => {
  if (!list) return null;

  const itemsWithProduct = list.presetItems
    .map((item) => {
      const prod = allProducts.find((p) => p.id === item.productId);
      if (!prod) return null;
      return { product: prod, quantity: item.quantity };
    })
    .filter((i): i is { product: Product; quantity: number } => i !== null);

  const totalCalculated = itemsWithProduct.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const handleAddAndClose = () => {
    onAddListToCart(itemsWithProduct);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-orange-200 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-[#f97316] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-amber-200" />
            <div>
              <h3 className="font-extrabold text-base leading-tight">{list.title}</h3>
              <p className="text-xs text-orange-100">{list.subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-md hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Products list */}
        <div className="p-4 overflow-y-auto space-y-2.5 flex-1 bg-[#faf6f0]/40">
          <div className="flex items-center justify-between text-xs text-gray-500 font-semibold px-1">
            <span>Productos incluidos ({itemsWithProduct.length})</span>
            <span className="text-orange-600 bg-orange-100 px-2 py-0.5 rounded-full font-bold">
              {list.badge}
            </span>
          </div>

          {itemsWithProduct.map(({ product, quantity }) => (
            <div
              key={product.id}
              className="bg-white p-3 rounded-xl border border-gray-200/80 shadow-2xs flex items-center justify-between gap-3"
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-12 h-12 rounded-lg object-cover shrink-0"
              />

              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-xs sm:text-sm text-gray-900 truncate">
                  {product.name}
                </h4>
                <p className="text-[11px] text-gray-500 truncate flex items-center gap-1 mt-0.5">
                  <Store className="w-3 h-3 text-orange-500" />
                  <span>{product.stallName} · {product.marketName}</span>
                </p>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-xs font-black text-gray-900">
                    ${(product.price * quantity).toLocaleString('es-CO')} COP
                  </span>
                  <span className="text-[10px] text-gray-400">
                    ({quantity} {product.unit})
                  </span>
                </div>
              </div>

              {product.freshBadge && (
                <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-md border border-emerald-200/50 shrink-0">
                  {product.freshBadge}
                </span>
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 bg-white border-t border-gray-100 space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="font-bold text-gray-600">Total del combo estimado:</span>
            <span className="font-black text-lg text-orange-600">
              ${totalCalculated.toLocaleString('es-CO')} COP
            </span>
          </div>

          <button
            onClick={handleAddAndClose}
            className="w-full bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white font-extrabold py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Añadir combo completo a la canasta</span>
          </button>
        </div>
      </div>
    </div>
  );
};
