import React, { useState } from 'react';
import { Bookmark, Plus, Check, Sparkles, ChevronRight, ShoppingBag } from 'lucide-react';
import { QuickListItem, Product } from '../types';

interface UpcomingPurchasesProps {
  quickLists: QuickListItem[];
  allProducts: Product[];
  onAddPresetToCart: (items: { product: Product; quantity: number }[]) => void;
  onOpenAiWithPrompt: (prompt: string) => void;
  onViewBasketDetails: (list: QuickListItem) => void;
}

export const UpcomingPurchases: React.FC<UpcomingPurchasesProps> = ({
  quickLists,
  allProducts,
  onAddPresetToCart,
  onOpenAiWithPrompt,
  onViewBasketDetails,
}) => {
  const [addedListId, setAddedListId] = useState<string | null>(null);

  const handleAddList = (list: QuickListItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const itemsToAdd = list.presetItems
      .map((item) => {
        const prod = allProducts.find((p) => p.id === item.productId);
        if (!prod) return null;
        return { product: prod, quantity: item.quantity };
      })
      .filter((i): i is { product: Product; quantity: number } => i !== null);

    onAddPresetToCart(itemsToAdd);
    setAddedListId(list.id);
    setTimeout(() => setAddedListId(null), 1800);
  };

  return (
    <div className="bg-[#ffe8dc] border-2 border-[#fdb48e] rounded-2xl p-4 shadow-xs">
      {/* Title with icon matching mockup flag/bookmark icon */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {/* Small orange bookmark/flag icon from mockup */}
          <span className="text-[#ea580c] text-base select-none" role="img" aria-label="compras">
            🚩
          </span>
          <h3 className="font-extrabold text-gray-900 text-sm sm:text-base tracking-tight">
            Próximas Compras
          </h3>
        </div>

        <span className="text-[11px] font-bold text-orange-800 bg-[#ffd4be] px-2 py-0.5 rounded-full">
          Combos Frecuentes
        </span>
      </div>

      {/* List items matching the mockup's clean white cards */}
      <div className="space-y-2">
        {quickLists.map((list) => {
          const isAdded = addedListId === list.id;
          return (
            <div
              key={list.id}
              onClick={() => onViewBasketDetails(list)}
              className="group bg-white hover:bg-orange-50/70 p-3 rounded-xl border border-[#fed7aa] hover:border-orange-400 transition-all cursor-pointer shadow-xs flex items-center justify-between gap-2.5"
              role="button"
              tabIndex={0}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <h4 className="font-extrabold text-xs sm:text-sm text-gray-900 group-hover:text-orange-600 transition-colors truncate">
                    {list.title}
                  </h4>
                  <span className="text-[10px] bg-orange-100 text-orange-800 font-bold px-1.5 py-0.2 rounded-sm shrink-0">
                    {list.badge}
                  </span>
                </div>
                <p className="text-[11px] text-gray-500 truncate mt-0.5">
                  {list.subtitle}
                </p>
                <div className="flex items-center gap-2 text-[10px] text-gray-500 mt-1 font-semibold">
                  <span className="text-gray-600">{list.itemCount} productos</span>
                  <span>·</span>
                  <span className="text-orange-600 font-extrabold">
                    ~${list.estimatedPrice.toLocaleString('es-CO')} COP
                  </span>
                </div>
              </div>

              {/* Add button */}
              <button
                onClick={(e) => handleAddList(list, e)}
                className={`w-8 h-8 rounded-lg text-xs font-bold flex items-center justify-center shrink-0 transition-all ${
                  isAdded
                    ? 'bg-emerald-600 text-white'
                    : 'bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white shadow-2xs hover:scale-105'
                }`}
                title="Añadir combo a la canasta"
              >
                {isAdded ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Plus className="w-4 h-4" />
                )}
              </button>
            </div>
          );
        })}
      </div>

      {/* AI custom list button */}
      <button
        onClick={() => onOpenAiWithPrompt('Crea una canasta de mercado inteligente para mi semana con presupuesto de $45.000 COP')}
        className="w-full mt-3 py-2.5 px-3 bg-white hover:bg-[#fff5eb] border border-dashed border-[#ea580c] rounded-xl text-xs font-bold text-[#ea580c] flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
      >
        <Sparkles className="w-3.5 h-3.5 text-orange-500 fill-orange-300" />
        <span>Crear lista personalizada con IA</span>
        <ChevronRight className="w-3 h-3 text-orange-400 ml-auto" />
      </button>
    </div>
  );
};
