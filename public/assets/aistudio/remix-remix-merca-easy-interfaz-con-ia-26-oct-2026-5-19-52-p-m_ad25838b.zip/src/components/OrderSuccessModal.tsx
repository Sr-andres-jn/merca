import React, { useState, useEffect } from 'react';
import { CheckCircle2, Clock, Truck, Home, MapPin, X, Sparkles } from 'lucide-react';
import { Order } from '../types';

interface OrderSuccessModalProps {
  order: Order | null;
  onClose: () => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({ order, onClose }) => {
  const [step, setStep] = useState<number>(1);

  useEffect(() => {
    if (!order) return;
    setStep(1);

    const timer1 = setTimeout(() => setStep(2), 3500);
    const timer2 = setTimeout(() => setStep(3), 8500);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [order]);

  if (!order) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-orange-200">
        {/* Top Header */}
        <div className="bg-emerald-600 text-white p-5 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-white/80 hover:text-white p-1 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-12 h-12 bg-white/20 backdrop-blur-xs rounded-full flex items-center justify-center mx-auto mb-2 text-white">
            <CheckCircle2 className="w-7 h-7" />
          </div>

          <h3 className="font-black text-lg">¡Pedido Confirmado con Éxito!</h3>
          <p className="text-xs text-emerald-100 mt-0.5">
            Orden #{order.id} · {order.marketName}
          </p>
        </div>

        {/* Live Delivery Tracker */}
        <div className="p-4 sm:p-5 space-y-4">
          <div className="bg-orange-50/70 rounded-xl p-3 border border-orange-200">
            <h4 className="text-xs font-bold text-orange-900 mb-3 flex items-center justify-between">
              <span>Estado en vivo de tu plaza:</span>
              <span className="text-[10px] bg-orange-200 text-orange-800 px-2 py-0.5 rounded-full font-semibold">
                Estimado: 25 - 35 min
              </span>
            </h4>

            {/* Stepper */}
            <div className="space-y-2.5">
              {/* Step 1 */}
              <div className="flex items-center gap-3 text-xs">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 font-bold ${
                    step >= 1 ? 'bg-emerald-600 text-white' : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <p className="font-bold text-gray-900">1. Puesto notificado en la plaza</p>
                  <p className="text-[11px] text-gray-500">Seleccionando frutas y verduras del día</p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex items-center gap-3 text-xs">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 font-bold ${
                    step >= 2 ? 'bg-emerald-600 text-white' : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  <Truck className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <p className="font-bold text-gray-900">2. En camino con el repartidor</p>
                  <p className="text-[11px] text-gray-500">Transporte con canastilla aislada</p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex items-center gap-3 text-xs">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 font-bold ${
                    step >= 3 ? 'bg-emerald-600 text-white' : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  <Home className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <p className="font-bold text-gray-900">3. Entrega en tu puerta</p>
                  <p className="text-[11px] text-gray-500">{order.address}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="border border-gray-100 rounded-xl p-3 text-xs space-y-1.5 text-gray-600">
            <div className="flex justify-between">
              <span>Cliente:</span>
              <strong className="text-gray-900">{order.customerName}</strong>
            </div>
            <div className="flex justify-between">
              <span>Método:</span>
              <span className="text-gray-900">{order.paymentMethod}</span>
            </div>
            <div className="flex justify-between">
              <span>Total cancelado:</span>
              <strong className="text-orange-600 font-extrabold text-sm">
                ${order.total.toLocaleString('es-CO')} COP
              </strong>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full bg-[#f97316] hover:bg-[#ea580c] text-white font-extrabold py-2.5 px-4 rounded-xl text-xs sm:text-sm transition-colors"
          >
            Continuar Explorando Plazas
          </button>
        </div>
      </div>
    </div>
  );
};
