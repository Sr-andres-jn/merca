import React, { useState, useEffect } from 'react';
import {
  X,
  Database,
  Table,
  Users,
  Store,
  ShoppingBag,
  Package,
  Key,
  RefreshCw,
  Download,
  RotateCcw,
  CheckCircle2,
  HardDrive,
} from 'lucide-react';

interface DatabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DatabaseModal: React.FC<DatabaseModalProps> = ({ isOpen, onClose }) => {
  const [stats, setStats] = useState<any>(null);
  const [snapshot, setSnapshot] = useState<any>(null);
  const [activeTable, setActiveTable] = useState<'users' | 'orders' | 'products' | 'markets' | 'passwordResets'>('users');
  const [isLoading, setIsLoading] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  const fetchDatabaseInfo = async () => {
    setIsLoading(true);
    try {
      const [statsRes, snapRes] = await Promise.all([
        fetch('/api/db/stats').then((r) => r.json()),
        fetch('/api/db/snapshot').then((r) => r.json()),
      ]);

      if (statsRes.success) setStats(statsRes.stats);
      if (snapRes.success) setSnapshot(snapRes.snapshot);
    } catch (err) {
      console.error('Error loading database snapshot:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchDatabaseInfo();
    }
  }, [isOpen]);

  const handleReset = async () => {
    if (!window.confirm('¿Deseas restablecer la base de datos a sus valores iniciales?')) return;
    try {
      await fetch('/api/db/reset', { method: 'POST' });
      await fetchDatabaseInfo();
      setNotification('Base de datos restablecida correctamente.');
      setTimeout(() => setNotification(null), 3000);
    } catch {
      alert('Error restableciendo base de datos');
    }
  };

  const handleExport = () => {
    if (!snapshot) return;
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `merca_easy_database_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!isOpen) return null;

  const tables: { id: typeof activeTable; label: string; icon: React.ReactNode; count: number }[] = [
    { id: 'users', label: 'Usuarios', icon: <Users className="w-4 h-4" />, count: stats?.counts?.users || 0 },
    { id: 'orders', label: 'Pedidos', icon: <Package className="w-4 h-4" />, count: stats?.counts?.orders || 0 },
    { id: 'products', label: 'Productos', icon: <ShoppingBag className="w-4 h-4" />, count: stats?.counts?.products || 0 },
    { id: 'markets', label: 'Mercados', icon: <Store className="w-4 h-4" />, count: stats?.counts?.markets || 0 },
    { id: 'passwordResets', label: 'Recuperaciones', icon: <Key className="w-4 h-4" />, count: stats?.counts?.passwordResets || 0 },
  ];

  const currentRecords = snapshot ? snapshot[activeTable] || [] : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn select-none">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden border border-orange-200 flex flex-col max-h-[90vh]">
        {/* Top Header */}
        <div className="bg-[#1f2937] text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-orange-500 rounded-xl text-white shadow-xs">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-base sm:text-lg">Base de Datos Funcional</h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-extrabold px-2 py-0.5 rounded-full border border-emerald-500/40">
                  Activa & Persistente
                </span>
              </div>
              <p className="text-xs text-gray-400">
                Almacenamiento persistente en disco JSON con CRUD y transacciones
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={fetchDatabaseInfo}
              disabled={isLoading}
              className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
              title="Actualizar datos"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Cerrar modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notification bar */}
        {notification && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-4 py-2 text-xs text-emerald-800 font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{notification}</span>
          </div>
        )}

        {/* Database Metrics Bar */}
        <div className="bg-gray-50 border-b border-gray-200 p-3 sm:px-5 flex flex-wrap items-center justify-between gap-2 text-xs text-gray-600">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <HardDrive className="w-4 h-4 text-orange-600" />
              <span>Archivo: <strong className="text-gray-900">data/database.json</strong></span>
            </div>
            <div className="hidden sm:inline">
              Última actualización: <strong className="text-gray-900">{stats?.lastUpdated ? new Date(stats.lastUpdated).toLocaleTimeString() : 'N/A'}</strong>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExport}
              className="flex items-center gap-1 bg-white hover:bg-gray-100 text-gray-700 font-bold py-1 px-2.5 rounded-lg border border-gray-200 text-xs shadow-2xs transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Exportar JSON</span>
            </button>
            <button
              onClick={handleReset}
              className="flex items-center gap-1 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold py-1 px-2.5 rounded-lg border border-rose-200 text-xs shadow-2xs transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restablecer Semilla</span>
            </button>
          </div>
        </div>

        {/* Table Selector Tabs */}
        <div className="flex items-center gap-1.5 p-3 overflow-x-auto bg-white border-b border-gray-100 scrollbar-none">
          {tables.map((tbl) => {
            const isActive = activeTable === tbl.id;
            return (
              <button
                key={tbl.id}
                onClick={() => setActiveTable(tbl.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-orange-500 text-white shadow-xs'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                }`}
              >
                {tbl.icon}
                <span>{tbl.label}</span>
                <span
                  className={`px-1.5 py-0.2 text-[10px] rounded-full font-black ${
                    isActive ? 'bg-orange-700 text-white' : 'bg-gray-200 text-gray-700'
                  }`}
                >
                  {tbl.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Records Content */}
        <div className="flex-1 overflow-y-auto p-4 bg-[#f8fafc] font-mono text-xs">
          {currentRecords.length === 0 ? (
            <div className="text-center py-12 text-gray-400 font-sans">
              <Table className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="font-bold">No hay registros en la tabla '{activeTable}'</p>
            </div>
          ) : (
            <div className="space-y-3">
              {currentRecords.map((item: any, idx: number) => (
                <div
                  key={item.id || idx}
                  className="bg-white p-3.5 rounded-2xl border border-gray-200 shadow-2xs space-y-1.5 text-gray-800"
                >
                  <div className="flex items-center justify-between pb-1 border-b border-gray-100 font-sans">
                    <span className="font-black text-xs text-orange-600 bg-orange-50 px-2 py-0.5 rounded-md">
                      #{item.id || idx + 1}
                    </span>
                    <span className="text-[11px] text-gray-400">
                      {item.createdAt ? new Date(item.createdAt).toLocaleString() : ''}
                    </span>
                  </div>

                  <pre className="text-[11px] text-gray-700 overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-48 scrollbar-none font-mono">
                    {JSON.stringify(item, null, 2)}
                  </pre>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 bg-white border-t border-gray-200 flex items-center justify-between text-xs text-gray-500 font-sans">
          <span>{currentRecords.length} registros cargados en memoria y sincronizados con disco.</span>
          <button
            onClick={onClose}
            className="bg-gray-900 hover:bg-black text-white font-extrabold py-1.5 px-4 rounded-xl transition-colors"
          >
            Cerrar Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
