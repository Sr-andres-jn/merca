import React from 'react';
import { Package, Clock, Truck, CheckCircle2, ChevronRight, Store, ArrowRight, LogIn } from 'lucide-react';
import { Order, AuthUser } from '../types';

interface OrdersViewProps {
  orders: Order[];
  user?: AuthUser | null;
  onOpenAuth?: (mode?: 'login' | 'register') => void;
  onSelectOrder: (order: Order) => void;
  onExploreMarkets: () => void;
}

export const OrdersView: React.FC<OrdersViewProps> = ({
  orders,
  user,
  onOpenAuth,
  onSelectOrder,
  onExploreMarkets,
}) => {
  return (
    <div className="space-y-4 p-4">
      {/* Auth Banner if not logged in */}
      {!user && onOpenAuth && (
        <div className="bg-gradient-to-r from-orange-500 to-amber-500 rounded-2xl p-3.5 text-white shadow-xs flex items-center justify-between gap-3">
          <div className="text-xs">
            <p className="font-extrabold text-sm">¿Tienes cuenta en Merca Easy?</p>
            <p className="text-orange-100 text-[11px]">Inicia sesión para guardar y sincronizar tus pedidos.</p>
          </div>
          <button
            onClick={() => onOpenAuth('login')}
            className="bg-white text-orange-700 hover:bg-orange-50 font-black text-xs px-3 py-1.5 rounded-xl shrink-0 shadow-2xs flex items-center gap-1"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Ingresar</span>
          </button>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-gray-900">Mis Pedidos de Plaza</h2>
          <p className="text-xs text-gray-500">Historial y seguimiento de tus compras con IA</p>
        </div>
        <span className="text-xs bg-orange-100 text-orange-800 font-bold px-2.5 py-1 rounded-full">
          {orders.length} pedidos
        </span>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-16 px-4 bg-white rounded-2xl border border-orange-100 shadow-xs">
          <div className="w-16 h-16 bg-orange-100 text-[#f97316] rounded-full flex items-center justify-center mx-auto mb-3">
            <Package className="w-8 h-8" />
          </div>
          <h3 className="font-extrabold text-gray-900 text-base">Aún no tienes pedidos</h3>
          <p className="text-xs text-gray-500 mt-1 max-w-xs mx-auto">
            Explora las plazas de mercado o dile al Asistente IA que arme tu mercado hoy.
          </p>
          <button
            onClick={onExploreMarkets}
            className="mt-4 bg-[#f97316] hover:bg-[#ea580c] text-white text-xs font-bold py-2.5 px-4 rounded-xl shadow-xs transition-all inline-flex items-center gap-1.5"
          >
            <span>Ver Plazas Disponibles</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order) => (
            <div
              key={order.id}
              onClick={() => onSelectOrder(order)}
              className="bg-white rounded-2xl border border-orange-200/80 p-4 shadow-xs hover:border-orange-400 cursor-pointer transition-all space-y-2.5"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-orange-600 bg-orange-50 px-2 py-0.5 rounded-md border border-orange-200">
                  #{order.id}
                </span>
                <span className="text-xs font-extrabold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>En preparación</span>
                </span>
              </div>

              <div className="text-xs">
                <p className="font-bold text-gray-900 flex items-center gap-1">
                  <Store className="w-3.5 h-3.5 text-orange-500" />
                  {order.marketName}
                </p>
                <p className="text-gray-500 text-[11px] mt-0.5">
                  {order.items.length} productos · {new Date(order.createdAt).toLocaleDateString('es-CO')}
                </p>
              </div>

              <div className="pt-2 border-t border-gray-100 flex items-center justify-between text-xs">
                <div>
                  <span className="text-gray-400 text-[10px] block">Total pagado:</span>
                  <span className="font-black text-gray-900 text-sm">
                    ${order.total.toLocaleString('es-CO')} COP
                  </span>
                </div>

                <div className="flex items-center gap-1 text-orange-600 font-bold text-xs">
                  <span>Rastrear</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
