import React from 'react';
import { Store, Calendar, HelpCircle, ShoppingBag, Sparkles, ShoppingCart, CheckCircle2 } from 'lucide-react';

export type AppStep = 'mercados' | 'compras' | 'que_es' | 'catalogo' | 'asistente_ia' | 'canasta';

interface StepGuideProps {
  currentStep: AppStep;
  onSelectStep: (step: AppStep) => void;
  cartCount: number;
}

export const StepGuide: React.FC<StepGuideProps> = ({
  currentStep,
  onSelectStep,
  cartCount,
}) => {
  const steps: { id: AppStep; label: string; icon: React.ReactNode; number: number }[] = [
    { id: 'mercados', label: '1. Mercados Disponibles', icon: <Store className="w-3.5 h-3.5" />, number: 1 },
    { id: 'compras', label: '2. Próximas Compras', icon: <Calendar className="w-3.5 h-3.5" />, number: 2 },
    { id: 'que_es', label: '3. ¿Qué es Merca Easy?', icon: <HelpCircle className="w-3.5 h-3.5" />, number: 3 },
    { id: 'catalogo', label: '4. Catálogo y Puestos', icon: <ShoppingBag className="w-3.5 h-3.5" />, number: 4 },
    { id: 'asistente_ia', label: '5. Interfaz con IA', icon: <Sparkles className="w-3.5 h-3.5" />, number: 5 },
    { id: 'canasta', label: `6. Canasta (${cartCount})`, icon: <ShoppingCart className="w-3.5 h-3.5" />, number: 6 },
  ];

  return (
    <div className="bg-white border-b border-orange-200/80 shadow-xs px-3 sm:px-6 py-2">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-1.5 shrink-0 text-xs font-bold text-gray-500 mr-2">
          <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
          <span className="hidden md:inline">Flujo del Prototipo:</span>
        </div>

        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {steps.map((step) => {
            const isActive = currentStep === step.id;
            return (
              <button
                key={step.id}
                onClick={() => onSelectStep(step.id)}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-orange-500 text-white shadow-xs font-bold'
                    : 'bg-orange-50/60 hover:bg-orange-100 text-orange-950 hover:text-orange-900 border border-orange-200/50'
                }`}
              >
                {step.icon}
                <span>{step.label}</span>
                {isActive && <CheckCircle2 className="w-3 h-3 text-white ml-0.5" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
