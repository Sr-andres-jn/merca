import React from 'react';
import { X, Trash2, Plus, Minus, ArrowRight, ShoppingCart, Sparkles, Store } from 'lucide-react';
import { CartItem, Product } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (product: Product, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onProceedToCheckout: () => void;
  onOpenAi: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onProceedToCheckout,
  onOpenAi,
}) => {
  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const deliveryFee = subtotal > 0 ? 4500 : 0;
  // Apply a $3.000 discount if subtotal exceeds $30.000
  const aiDiscount = subtotal >= 30000 ? 3000 : 0;
  const total = Math.max(0, subtotal + deliveryFee - aiDiscount);

  // Group items by market
  const itemsByMarket = cart.reduce((acc, item) => {
    const marketName = item.product.marketName;
    if (!acc[marketName]) {
      acc[marketName] = [];
    }
    acc[marketName].push(item);
    return acc;
  }, {} as Record<string, CartItem[]>);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          {/* Header */}
          <div className="bg-[#f97316] text-white p-4 flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              <h3 className="font-extrabold text-base">Mi Canasta de Mercado</h3>
              <span className="text-xs bg-white text-orange-600 font-extrabold px-2 py-0.5 rounded-full">
                {cart.reduce((s, i) => s + i.quantity, 0)}
              </span>
            </div>

            <div className="flex items-center gap-1">
              {cart.length > 0 && (
                <button
                  onClick={onClearCart}
                  className="p-1.5 text-orange-200 hover:text-white rounded-md text-xs hover:bg-orange-700 transition-colors"
                  title="Vaciar carrito"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onClose}
                className="p-1.5 rounded-md text-white/80 hover:text-white hover:bg-white/10 transition-colors"
                aria-label="Cerrar carrito"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-16 px-4">
                <div className="w-16 h-16 bg-orange-100 text-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <ShoppingCart className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-gray-800 text-base">Tu canasta está vacía</h4>
                <p className="text-xs text-gray-500 mt-1 max-w-xs mx-auto">
                  Agrega frutas, verduras, carnes de la plaza o pídele a la IA que arme tu mercado.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenAi();
                  }}
                  className="mt-4 inline-flex items-center gap-1.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold py-2 px-4 rounded-xl transition-colors shadow-xs"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Armar mercado con IA</span>
                </button>
              </div>
            ) : (
              Object.entries(itemsByMarket).map(([marketName, items]) => (
                <div key={marketName} className="space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-orange-800 bg-orange-50 px-2.5 py-1 rounded-lg border border-orange-200/50">
                    <Store className="w-3.5 h-3.5 text-orange-600" />
                    <span>{marketName}</span>
                  </div>

                  <div className="space-y-2 pl-1">
                    {items.map((item) => (
                      <div
                        key={item.product.id}
                        className="bg-white rounded-xl border border-gray-200 p-2.5 flex items-center justify-between gap-2 shadow-xs"
                      >
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-12 h-12 rounded-lg object-cover shrink-0"
                        />

                        <div className="flex-1 min-w-0">
                          <h5 className="font-bold text-xs text-gray-900 truncate">
                            {item.product.name}
                          </h5>
                          <p className="text-[10px] text-gray-500 truncate">
                            {item.product.stallName}
                          </p>
                          <div className="flex items-baseline gap-1 mt-0.5">
                            <span className="font-extrabold text-xs text-gray-900">
                              ${(item.product.price * item.quantity).toLocaleString('es-CO')}
                            </span>
                            <span className="text-[10px] text-gray-400">
                              (${item.product.price.toLocaleString('es-CO')}/{item.product.unit})
                            </span>
                          </div>
                        </div>

                        {/* Quantity Counter */}
                        <div className="flex items-center gap-1 bg-gray-50 border border-gray-200 rounded-lg p-0.5">
                          <button
                            onClick={() => onUpdateQuantity(item.product, -1)}
                            className="w-5 h-5 rounded flex items-center justify-center text-gray-600 hover:bg-gray-200 transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-bold px-1 min-w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.product, 1)}
                            className="w-5 h-5 rounded flex items-center justify-center text-gray-600 hover:bg-gray-200 transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer with Calculations */}
          {cart.length > 0 && (
            <div className="p-4 bg-gray-50 border-t border-gray-200 space-y-3">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal productos:</span>
                  <span className="font-semibold text-gray-900">
                    ${subtotal.toLocaleString('es-CO')} COP
                  </span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Envío directo desde plaza:</span>
                  <span className="font-semibold text-gray-900">
                    ${deliveryFee.toLocaleString('es-CO')} COP
                  </span>
                </div>
                {aiDiscount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-emerald-600" />
                      Descuento Plaza Directo:
                    </span>
                    <span>-${aiDiscount.toLocaleString('es-CO')} COP</span>
                  </div>
                )}
                <div className="pt-2 border-t border-gray-200 flex justify-between text-sm font-extrabold text-gray-900">
                  <span>Total a pagar:</span>
                  <span className="text-base text-orange-600">
                    ${total.toLocaleString('es-CO')} COP
                  </span>
                </div>
              </div>

              <button
                onClick={onProceedToCheckout}
                className="w-full bg-[#f97316] hover:bg-[#ea580c] active:bg-[#c2410c] text-white font-extrabold py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm"
              >
                <span>Confirmar y Finalizar Pedido</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
