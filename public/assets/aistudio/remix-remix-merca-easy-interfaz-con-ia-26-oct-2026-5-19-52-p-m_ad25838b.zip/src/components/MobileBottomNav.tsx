import React from 'react';
import { Store, ShoppingBag, Sparkles, ShoppingCart, Clock } from 'lucide-react';

export type MobileTab = 'inicio' | 'productos' | 'ia' | 'canasta' | 'pedidos';

interface MobileBottomNavProps {
  activeTab: MobileTab;
  onSelectTab: (tab: MobileTab) => void;
  cartCount: number;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  onSelectTab,
  cartCount,
}) => {
  const tabs: { id: MobileTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    {
      id: 'inicio',
      label: 'Mercados',
      icon: <Store className="w-5 h-5" />,
    },
    {
      id: 'productos',
      label: 'Catálogo',
      icon: <ShoppingBag className="w-5 h-5" />,
    },
    {
      id: 'ia',
      label: 'Merca IA',
      icon: <Sparkles className="w-5 h-5 fill-amber-400 text-orange-500" />,
    },
    {
      id: 'canasta',
      label: 'Canasta',
      icon: <ShoppingCart className="w-5 h-5" />,
      badge: cartCount,
    },
    {
      id: 'pedidos',
      label: 'Pedidos',
      icon: <Clock className="w-5 h-5" />,
    },
  ];

  return (
    <nav className="sticky bottom-0 z-40 bg-white border-t border-orange-200/80 shadow-lg px-2 py-1.5 flex items-center justify-around select-none">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            className={`relative flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all ${
              isActive
                ? 'text-[#f97316] font-extrabold scale-105'
                : 'text-gray-500 hover:text-orange-600 font-medium'
            }`}
          >
            <div className="relative">
              {tab.icon}
              {tab.badge !== undefined && tab.badge > 0 && (
                <span className="absolute -top-1.5 -right-2.5 bg-[#f97316] text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                  {tab.badge}
                </span>
              )}
            </div>
            <span className="text-[10px] mt-0.5 tracking-tight">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
