import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Market, Product, Order, QuickListItem, AuthUser } from '../types';
import { INITIAL_MARKETS, INITIAL_PRODUCTS, QUICK_LISTS } from '../data/mockData';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.join(__dirname, '..', '..', 'data', 'database.json');

export interface StoredUser extends AuthUser {
  passwordHash?: string;
  createdAt: string;
}

export interface PasswordResetRecord {
  id: string;
  emailOrPhone: string;
  code: string;
  expiresAt: string;
  used: boolean;
}

export interface DatabaseSchema {
  version: number;
  lastUpdated: string;
  users: StoredUser[];
  markets: Market[];
  products: Product[];
  quickLists: QuickListItem[];
  orders: Order[];
  passwordResets: PasswordResetRecord[];
}

class LocalDatabase {
  private data: DatabaseSchema;
  private filePath: string;
  private isSaving: boolean = false;

  constructor(filePath: string) {
    this.filePath = filePath;
    this.data = this.loadOrSeed();
  }

  private loadOrSeed(): DatabaseSchema {
    try {
      const dir = path.dirname(this.filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        const parsed = JSON.parse(raw);
        // Ensure all arrays exist
        return {
          version: parsed.version || 1,
          lastUpdated: parsed.lastUpdated || new Date().toISOString(),
          users: parsed.users || [],
          markets: parsed.markets?.length ? parsed.markets : INITIAL_MARKETS,
          products: parsed.products?.length ? parsed.products : INITIAL_PRODUCTS,
          quickLists: parsed.quickLists?.length ? parsed.quickLists : QUICK_LISTS,
          orders: parsed.orders || [],
          passwordResets: parsed.passwordResets || [],
        };
      }
    } catch (err) {
      console.warn('[Database] Could not read existing DB file, seeding fresh database:', err);
    }

    // Default Seed
    const seed: DatabaseSchema = {
      version: 1,
      lastUpdated: new Date().toISOString(),
      users: [
        {
          id: 'usr-admin',
          name: 'Andrés Morales',
          emailOrPhone: 'andres@mercaeasy.co',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
          provider: 'email',
          createdAt: new Date().toISOString(),
        },
        {
          id: 'usr-demo',
          name: 'María Gómez',
          emailOrPhone: '3101234567',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
          provider: 'email',
          createdAt: new Date().toISOString(),
        },
      ],
      markets: INITIAL_MARKETS,
      products: INITIAL_PRODUCTS,
      quickLists: QUICK_LISTS,
      orders: [
        {
          id: 'ORD-892104',
          createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
          items: [
            { product: INITIAL_PRODUCTS[0], quantity: 2 },
            { product: INITIAL_PRODUCTS[1], quantity: 1 },
          ],
          subtotal: 12200,
          deliveryFee: 4500,
          discount: 0,
          total: 16700,
          marketName: 'Plaza Central de Madrid',
          status: 'entregado',
          customerName: 'Andrés Morales',
          address: 'Calle 7 # 5-40, Barrio San Carlos, Madrid, Cundinamarca',
          paymentMethod: 'Nequi / Daviplata',
        },
      ],
      passwordResets: [
        {
          id: 'rst-init',
          emailOrPhone: 'andres@mercaeasy.co',
          code: '849216',
          expiresAt: new Date(Date.now() + 86400000).toISOString(),
          used: false,
        },
      ],
    };

    this.saveImmediate(seed);
    return seed;
  }

  private save(): void {
    if (this.isSaving) return;
    this.isSaving = true;
    setTimeout(() => {
      this.saveImmediate(this.data);
      this.isSaving = false;
    }, 50);
  }

  private saveImmediate(data: DatabaseSchema): void {
    try {
      const dir = path.dirname(this.filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      data.lastUpdated = new Date().toISOString();
      fs.writeFileSync(this.filePath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('[Database] Error saving database file:', err);
    }
  }

  // --- STATS & ADMIN ---
  public getStats() {
    return {
      version: this.data.version,
      lastUpdated: this.data.lastUpdated,
      counts: {
        users: this.data.users.length,
        markets: this.data.markets.length,
        products: this.data.products.length,
        quickLists: this.data.quickLists.length,
        orders: this.data.orders.length,
        passwordResets: this.data.passwordResets.length,
      },
      filePath: this.filePath,
    };
  }

  public getFullSnapshot(): DatabaseSchema {
    return JSON.parse(JSON.stringify(this.data));
  }

  public resetDatabase(): void {
    this.data = this.loadOrSeed();
    this.saveImmediate(this.data);
  }

  // --- USERS CRUD ---
  public getUsers(): StoredUser[] {
    return this.data.users.map(({ passwordHash, ...safe }) => safe as StoredUser);
  }

  public findUserByEmailOrPhone(query: string): StoredUser | undefined {
    const q = query.toLowerCase().trim();
    return this.data.users.find(
      (u) => u.emailOrPhone.toLowerCase().trim() === q
    );
  }

  public createUser(user: {
    name: string;
    emailOrPhone: string;
    password?: string;
    provider?: 'email' | 'google' | 'apple';
    avatar?: string;
  }): StoredUser {
    const existing = this.findUserByEmailOrPhone(user.emailOrPhone);
    if (existing) {
      throw new Error('Ya existe un usuario con este correo electrónico o teléfono');
    }

    const newUser: StoredUser = {
      id: `usr-${Date.now().toString().slice(-6)}`,
      name: user.name,
      emailOrPhone: user.emailOrPhone.trim(),
      passwordHash: user.password ? `hashed_${user.password}` : undefined,
      avatar:
        user.avatar ||
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
      provider: user.provider || 'email',
      createdAt: new Date().toISOString(),
    };

    this.data.users.unshift(newUser);
    this.save();

    const { passwordHash, ...safeUser } = newUser;
    return safeUser as StoredUser;
  }

  public verifyCredentials(emailOrPhone: string, passwordAttempt: string): StoredUser | null {
    const user = this.findUserByEmailOrPhone(emailOrPhone);
    if (!user) return null;
    if (user.passwordHash && user.passwordHash !== `hashed_${passwordAttempt}`) {
      // In a real environment use bcrypt/argon2; for local dev simulation we use prefixed hash
      return null;
    }
    const { passwordHash, ...safeUser } = user;
    return safeUser as StoredUser;
  }

  public updatePassword(emailOrPhone: string, newPassword: string): boolean {
    const user = this.findUserByEmailOrPhone(emailOrPhone);
    if (!user) return false;
    user.passwordHash = `hashed_${newPassword}`;
    this.save();
    return true;
  }

  // --- PASSWORD RESETS ---
  public createPasswordReset(emailOrPhone: string): PasswordResetRecord {
    const record: PasswordResetRecord = {
      id: `rst-${Date.now().toString().slice(-6)}`,
      emailOrPhone: emailOrPhone.trim(),
      code: Math.floor(100000 + Math.random() * 900000).toString(),
      expiresAt: new Date(Date.now() + 15 * 60000).toISOString(), // 15 mins
      used: false,
    };
    this.data.passwordResets.unshift(record);
    this.save();
    return record;
  }

  public verifyResetCode(emailOrPhone: string, code: string): boolean {
    const q = emailOrPhone.toLowerCase().trim();
    const record = this.data.passwordResets.find(
      (r) => r.emailOrPhone.toLowerCase().trim() === q && r.code === code && !r.used
    );
    if (!record) {
      // Allow demo code '849216'
      return code === '849216';
    }
    return true;
  }

  public markResetCodeUsed(emailOrPhone: string, code: string): void {
    const q = emailOrPhone.toLowerCase().trim();
    const record = this.data.passwordResets.find(
      (r) => r.emailOrPhone.toLowerCase().trim() === q && r.code === code
    );
    if (record) {
      record.used = true;
      this.save();
    }
  }

  // --- MARKETS CRUD ---
  public getMarkets(): Market[] {
    return this.data.markets;
  }

  public getMarketById(id: string): Market | undefined {
    return this.data.markets.find((m) => m.id === id);
  }

  // --- PRODUCTS CRUD ---
  public getProducts(filters?: { marketId?: string; category?: string; search?: string }): Product[] {
    let result = [...this.data.products];
    if (filters?.marketId && filters.marketId !== 'todos') {
      result = result.filter((p) => p.marketId === filters.marketId);
    }
    if (filters?.category && filters.category !== 'todos') {
      result = result.filter((p) => p.category === filters.category);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase().trim();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.stallName.toLowerCase().includes(q)
      );
    }
    return result;
  }

  public getProductById(id: string): Product | undefined {
    return this.data.products.find((p) => p.id === id);
  }

  public addProduct(product: Omit<Product, 'id'>): Product {
    const newProduct: Product = {
      ...product,
      id: `p-${Date.now().toString().slice(-6)}`,
    };
    this.data.products.unshift(newProduct);
    this.save();
    return newProduct;
  }

  // --- ORDERS CRUD ---
  public getOrders(userId?: string): Order[] {
    if (userId) {
      return this.data.orders.filter((o) => (o as any).userId === userId);
    }
    return this.data.orders;
  }

  public getOrderById(id: string): Order | undefined {
    return this.data.orders.find((o) => o.id === id);
  }

  public createOrder(orderData: Partial<Order>): Order {
    const newOrder: Order = {
      id: `ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      createdAt: new Date().toISOString(),
      items: orderData.items || [],
      subtotal: orderData.subtotal || 0,
      deliveryFee: orderData.deliveryFee ?? 4500,
      discount: orderData.discount || 0,
      total: orderData.total || 0,
      marketName: orderData.marketName || 'Plaza Central de Madrid',
      status: 'preparando',
      customerName: orderData.customerName || 'Cliente Merca Easy',
      address: orderData.address || 'Calle 7 # 5-40, Barrio San Carlos, Madrid, Cundinamarca',
      paymentMethod: orderData.paymentMethod || 'Nequi / Daviplata',
    };

    this.data.orders.unshift(newOrder);
    this.save();
    return newOrder;
  }

  public updateOrderStatus(orderId: string, status: 'preparando' | 'en_camino' | 'entregado'): Order | null {
    const order = this.data.orders.find((o) => o.id === orderId);
    if (!order) return null;
    order.status = status;
    this.save();
    return order;
  }

  // --- QUICK LISTS ---
  public getQuickLists(): QuickListItem[] {
    return this.data.quickLists;
  }
}

export const db = new LocalDatabase(DB_FILE);
