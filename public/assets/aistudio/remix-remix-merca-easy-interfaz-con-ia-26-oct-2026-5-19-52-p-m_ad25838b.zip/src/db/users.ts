import { db } from './index.ts';
import { users } from './schema.ts';
import { eq } from 'drizzle-orm';

export async function getOrCreateUser(uid: string, name: string, emailOrPhone: string, avatar?: string, provider?: string) {
  try {
    const result = await db.insert(users)
      .values({
        uid,
        name,
        emailOrPhone,
        avatar: avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120',
        provider: provider || 'google',
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          name,
          emailOrPhone,
          avatar: avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120',
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Failed to get or create user:', error);
    throw new Error('Database user sync failed', { cause: error });
  }
}

export async function getAllUsers() {
  try {
    return await db.select().from(users);
  } catch (error) {
    console.error('Failed to get users:', error);
    throw new Error('Database query failed', { cause: error });
  }
}
