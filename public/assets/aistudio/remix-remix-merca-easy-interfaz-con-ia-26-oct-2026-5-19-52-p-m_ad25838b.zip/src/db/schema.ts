import { pgTable, serial, text, integer, boolean, timestamp, jsonb } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase UID or local Auth ID
  name: text('name').notNull(),
  emailOrPhone: text('email_or_phone').notNull(),
  avatar: text('avatar'),
  provider: text('provider').default('email'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const markets = pgTable('markets', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  status: text('status').notNull(),
  distance: text('distance').notNull(),
  vendorsCount: integer('vendors_count').notNull(),
  description: text('description').notNull(),
  hours: text('hours').notNull(),
  rating: text('rating').notNull(),
  reviewsCount: integer('reviews_count').notNull(),
  deliveryTime: text('delivery_time').notNull(),
  accentColor: text('accent_color').notNull(),
  badgeText: text('badge_text'),
});

export const products = pgTable('products', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  category: text('category').notNull(),
  price: integer('price').notNull(),
  unit: text('unit').notNull(),
  image: text('image').notNull(),
  stallName: text('stall_name').notNull(),
  stallNumber: text('stall_number').notNull(),
  marketId: text('market_id').notNull(),
  marketName: text('market_name').notNull(),
  freshBadge: text('fresh_badge'),
  description: text('description').notNull(),
  inStock: boolean('in_stock').default(true),
  organic: boolean('organic').default(false),
});

export const orders = pgTable('orders', {
  id: text('id').primaryKey(),
  userId: text('user_id'),
  customerName: text('customer_name').notNull(),
  address: text('address').notNull(),
  paymentMethod: text('payment_method').notNull(),
  marketName: text('market_name').notNull(),
  status: text('status').notNull().default('preparando'),
  subtotal: integer('subtotal').notNull(),
  deliveryFee: integer('delivery_fee').notNull().default(4500),
  discount: integer('discount').notNull().default(0),
  total: integer('total').notNull(),
  items: jsonb('items').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export const passwordResets = pgTable('password_resets', {
  id: text('id').primaryKey(),
  emailOrPhone: text('email_or_phone').notNull(),
  code: text('code').notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  used: boolean('used').default(false),
});
