export interface Product {
  id: string;
  name: string;
  category: 'frutas' | 'verduras' | 'carnes' | 'pescados' | 'granos' | 'lacteos' | 'hierbas' | 'campesino';
  price: number; // in COP (Colombian Pesos)
  unit: string; // e.g. "kg", "lb", "atado", "bandeja", "docena"
  image: string;
  stallName: string;
  stallNumber: string;
  marketId: string;
  marketName: string;
  freshBadge?: string;
  description: string;
  inStock: boolean;
  organic?: boolean;
}

export interface Stall {
  id: string;
  name: string;
  number: string;
  category: string;
  marketId: string;
  rating: number;
  productsCount: number;
}

export interface Market {
  id: string;
  name: string;
  status: 'Abierto' | 'Cerrado';
  distance: string;
  vendorsCount: number;
  description: string;
  hours: string;
  rating: number;
  reviewsCount: number;
  deliveryTime: string;
  accentColor: string;
  badgeText: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface QuickListItem {
  id: string;
  title: string;
  subtitle: string;
  itemCount: number;
  estimatedPrice: number;
  badge: string;
  icon: string;
  presetItems: { productId: string; quantity: number }[];
}

export interface Order {
  id: string;
  createdAt: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  marketName: string;
  status: 'preparando' | 'en_camino' | 'entregado';
  customerName: string;
  address: string;
  paymentMethod: string;
}

export interface AiChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  suggestedProducts?: Product[];
  actionPrompt?: string;
  estimatedBudget?: number;
}

export interface AuthUser {
  id: string;
  name: string;
  emailOrPhone: string;
  avatar?: string;
  provider?: 'email' | 'google' | 'apple';
  phone?: string;
  defaultAddress?: string;
}

