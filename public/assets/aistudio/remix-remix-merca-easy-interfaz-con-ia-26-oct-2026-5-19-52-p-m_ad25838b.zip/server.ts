import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { db } from './src/db/database';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini API
let aiClient: GoogleGenAI | null = null;
try {
  aiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || '',
  });
} catch (err) {
  console.warn('GoogleGenAI initialization notice:', err);
}

// ==========================================
// DATABASE STATS & ADMIN ENDPOINTS
// ==========================================
app.get('/api/db/stats', (_req: Request, res: Response) => {
  res.json({ success: true, stats: db.getStats() });
});

app.get('/api/db/snapshot', (_req: Request, res: Response) => {
  res.json({ success: true, snapshot: db.getFullSnapshot() });
});

app.post('/api/db/reset', (_req: Request, res: Response) => {
  db.resetDatabase();
  res.json({ success: true, message: 'Base de datos restablecida con datos semilla.' });
});

// ==========================================
// AUTHENTICATION & USERS ENDPOINTS
// ==========================================
app.post('/api/auth/register', (req: Request, res: Response) => {
  try {
    const { name, emailOrPhone, password, provider, avatar } = req.body;
    if (!name || !emailOrPhone) {
      res.status(400).json({ success: false, error: 'Nombre y correo o teléfono requeridos' });
      return;
    }
    const user = db.createUser({ name, emailOrPhone, password, provider, avatar });
    res.status(201).json({ success: true, user });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { emailOrPhone, password } = req.body;
  if (!emailOrPhone || !password) {
    res.status(400).json({ success: false, error: 'Correo o teléfono y contraseña requeridos' });
    return;
  }
  const user = db.verifyCredentials(emailOrPhone, password);
  if (!user) {
    res.status(401).json({ success: false, error: 'Credenciales inválidas' });
    return;
  }
  res.json({ success: true, user });
});

app.post('/api/auth/forgot-password', (req: Request, res: Response) => {
  const { emailOrPhone } = req.body;
  if (!emailOrPhone) {
    res.status(400).json({ success: false, error: 'Correo o teléfono requerido' });
    return;
  }
  const resetRecord = db.createPasswordReset(emailOrPhone);
  res.json({
    success: true,
    message: 'Código de confirmación generado',
    code: resetRecord.code, // Returned for convenient preview in demo
  });
});

app.post('/api/auth/reset-password', (req: Request, res: Response) => {
  const { emailOrPhone, code, newPassword } = req.body;
  if (!emailOrPhone || !code || !newPassword) {
    res.status(400).json({ success: false, error: 'Todos los campos son requeridos' });
    return;
  }

  const isValidCode = db.verifyResetCode(emailOrPhone, code);
  if (!isValidCode) {
    res.status(400).json({ success: false, error: 'Código de confirmación inválido o expirado' });
    return;
  }

  const updated = db.updatePassword(emailOrPhone, newPassword);
  if (!updated) {
    // If user wasn't registered yet, create user record
    db.createUser({ name: emailOrPhone.split('@')[0], emailOrPhone, password: newPassword });
  }
  db.markResetCodeUsed(emailOrPhone, code);

  res.json({ success: true, message: 'Contraseña actualizada con éxito' });
});

// ==========================================
// MARKETS ENDPOINTS
// ==========================================
app.get('/api/markets', (_req: Request, res: Response) => {
  res.json({ success: true, markets: db.getMarkets() });
});

app.get('/api/markets/:id', (req: Request, res: Response) => {
  const market = db.getMarketById(req.params.id);
  if (!market) {
    res.status(404).json({ success: false, error: 'Mercado no encontrado' });
    return;
  }
  res.json({ success: true, market });
});

// ==========================================
// PRODUCTS ENDPOINTS
// ==========================================
app.get('/api/products', (req: Request, res: Response) => {
  const { marketId, category, search } = req.query;
  const products = db.getProducts({
    marketId: typeof marketId === 'string' ? marketId : undefined,
    category: typeof category === 'string' ? category : undefined,
    search: typeof search === 'string' ? search : undefined,
  });
  res.json({ success: true, products });
});

app.post('/api/products', (req: Request, res: Response) => {
  try {
    const newProduct = db.addProduct(req.body);
    res.status(201).json({ success: true, product: newProduct });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// ==========================================
// QUICK LISTS ENDPOINTS
// ==========================================
app.get('/api/quick-lists', (_req: Request, res: Response) => {
  res.json({ success: true, quickLists: db.getQuickLists() });
});

// ==========================================
// ORDERS ENDPOINTS
// ==========================================
app.get('/api/orders', (req: Request, res: Response) => {
  const { userId } = req.query;
  const orders = db.getOrders(typeof userId === 'string' ? userId : undefined);
  res.json({ success: true, orders });
});

app.post('/api/orders', (req: Request, res: Response) => {
  try {
    const order = db.createOrder(req.body);
    res.status(201).json({ success: true, order });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.put('/api/orders/:id/status', (req: Request, res: Response) => {
  const { status } = req.body;
  if (!status || !['preparando', 'en_camino', 'entregado'].includes(status)) {
    res.status(400).json({ success: false, error: 'Estado inválido' });
    return;
  }
  const updated = db.updateOrderStatus(req.params.id, status);
  if (!updated) {
    res.status(404).json({ success: false, error: 'Pedido no encontrado' });
    return;
  }
  res.json({ success: true, order: updated });
});

// ==========================================
// GEMINI AI ASSISTANT ENDPOINT
// ==========================================
app.post('/api/ai/assistant', async (req: Request, res: Response) => {
  try {
    const { message, history, currentCart, currentMarketId } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Mensaje requerido' });
      return;
    }

    const availableProducts = db.getProducts();
    const catalogSummary = availableProducts
      .map(
        (p) =>
          `- [ID: ${p.id}] ${p.name} ($${p.price.toLocaleString('es-CO')} COP/${p.unit}) en ${p.marketName} (${p.stallName})`
      )
      .join('\n');

    const systemInstruction = `
Eres el "Asistente Inteligente Merca Easy!", un experto consejero de compras en plazas de mercado y ferias campesinas de Madrid, Cundinamarca (como Plaza Central de Madrid, Mercado San José - La Prosperidad, Mercado El Sosiego y Feria Campesina de Madrid y veredas Puente de Piedra, El Corzo y Chueca).
Tu objetivo es ayudar a los usuarios de Madrid, Cundinamarca a encontrar los productos más frescos del campo, comparar precios justos, recomendar recetas tradicionales sabaneras y optimizar su presupuesto en Pesos Colombianos (COP).

Catálogo disponible actualmente en la base de datos de Madrid, Cundinamarca:
${catalogSummary}

Mercado seleccionado actualmente por el usuario: ${currentMarketId || 'Todos los mercados de Madrid, Cundinamarca'}
Productos actuales en su canasta: ${JSON.stringify(currentCart || [])}

Pautas de respuesta:
1. Sé cálido, amigable, conocedor de la tradición de las plazas de mercado de Madrid y la sabana ("¡Qué tal, vecino!", "con gusto le colaboro").
2. Brinda recomendaciones prácticas y precisas de cantidades y precios en COP.
3. Si recomiendas productos que coinciden con los del catálogo, incluye al final de tu respuesta un bloque JSON delimitado con \`\`\`json { "suggestedProductIds": ["id1", "id2"], "estimatedBudget": 35000, "tips": "..." } \`\`\` para que el sistema le permita agregarlos a la canasta con 1 click.
4. Mantén la respuesta concisa y fácil de leer con viñetas claras.
`;

    if (process.env.GEMINI_API_KEY && aiClient) {
      try {
        const prompt = `Historial previo: ${JSON.stringify(history || [])}\n\nPregunta del usuario: ${message}`;

        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        const responseText = response.text || '';

        let suggestedProductIds: string[] = [];
        let estimatedBudget = 0;
        const jsonMatch = responseText.match(/```json\s*(\{[\s\S]*?\})\s*```/);
        if (jsonMatch) {
          try {
            const parsed = JSON.parse(jsonMatch[1]);
            if (Array.isArray(parsed.suggestedProductIds)) {
              suggestedProductIds = parsed.suggestedProductIds;
            }
            if (parsed.estimatedBudget) {
              estimatedBudget = parsed.estimatedBudget;
            }
          } catch (e) {
            console.warn('Error parsing JSON from Gemini response', e);
          }
        }

        const cleanText = responseText.replace(/```json[\s\S]*?```/, '').trim();
        const suggestedProducts = availableProducts.filter((p) =>
          suggestedProductIds.includes(p.id)
        );

        res.json({
          success: true,
          reply: cleanText,
          suggestedProducts,
          estimatedBudget,
        });
        return;
      } catch (geminiError: any) {
        console.warn('Gemini API call notice, falling back to local heuristic:', geminiError?.message);
      }
    }

    // Local heuristic fallback for Madrid, Cundinamarca
    const query = message.toLowerCase();
    let reply = `¡Hola vecino de Madrid! En MERCA EASY te ayudamos a conseguir lo más fresco al mejor precio en las plazas de mercado de Madrid, Cundinamarca. `;
    let matchedIds: string[] = [];

    if (query.includes('ajiaco') || query.includes('sopa')) {
      reply += `Para un ajiaco sabanero delicioso necesitas papa criolla arenosa de vereda Chueca, pechuga campesina y cilantro fresco de Doña Rosa. Te he seleccionado los ingredientes directos de la plaza:`;
      matchedIds = ['fc-4', 'mc-5', 'mc-4', 'mc-1'];
    } else if (query.includes('fruta') || query.includes('jugo') || query.includes('desayuno')) {
      reply += `Tenemos mango tommy dulce recién cosechado, papaya maradol y fresas sabaneras de la vereda Puente de Piedra a precio de agricultor:`;
      matchedIds = ['mc-3', 'mc-6', 'fc-1'];
    } else if (query.includes('carne') || query.includes('proteina') || query.includes('pescado')) {
      reply += `Te recomiendo la pechuga de campo en la Plaza Central de Madrid o el corte fresco en Mercado San José (La Prosperidad):`;
      matchedIds = ['mc-5', 'pn-1', 'pn-2'];
    } else {
      reply += `Te seleccioné los productos más frescos y recomendados de hoy en la Plaza Central de Madrid y la Feria Campesina:`;
      matchedIds = ['mc-1', 'mc-2', 'fc-2', 'fc-1'];
    }

    const suggestedProducts = availableProducts.filter((p) => matchedIds.includes(p.id));
    const estimatedBudget = suggestedProducts.reduce((acc, curr) => acc + curr.price, 0);

    res.json({
      success: true,
      reply,
      suggestedProducts,
      estimatedBudget,
    });
  } catch (error: any) {
    console.error('Error in AI assistant endpoint:', error);
    res.status(500).json({
      success: false,
      error: 'Error procesando solicitud con IA',
      details: error.message,
    });
  }
});

// Setup Vite for development or static serving for production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[MERCA EASY SERVER & DB] Database running with persistent store at http://0.0.0.0:${PORT}`);
  });
}

startServer();
